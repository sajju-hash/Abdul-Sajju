/**
 * Upload Middleware
 * Multer configuration for file uploads
 */

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

// Ensure upload directories exist
const createUploadDirs = () => {
  const dirs = [
    'uploads/photos',
    'uploads/templates',
    'uploads/temp',
    'uploads/idcards',
    'uploads/logos',
  ];
  
  dirs.forEach(dir => {
    const fullPath = path.join(__dirname, '..', dir);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
    }
  });
};

createUploadDirs();

// Storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = 'uploads/temp';
    
    // Determine destination based on file type
    if (file.fieldname === 'photo' || file.fieldname === 'photos') {
      uploadPath = 'uploads/photos';
    } else if (file.fieldname === 'template') {
      uploadPath = 'uploads/templates';
    } else if (file.fieldname === 'logo') {
      uploadPath = 'uploads/logos';
    } else if (file.fieldname === 'excel') {
      uploadPath = 'uploads/temp';
    }
    
    cb(null, path.join(__dirname, '..', uploadPath));
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

// File filter
const fileFilter = (req, file, cb) => {
  const allowedTypes = {
    'photo': /jpeg|jpg|png|webp/,
    'photos': /jpeg|jpg|png|webp/,
    'template': /jpeg|jpg|png|webp/,
    'logo': /jpeg|jpg|png|webp|svg/,
    'excel': /xlsx|xls|csv/,
  };
  
  const fieldName = file.fieldname;
  const mimetype = allowedTypes[fieldName];
  const extname = allowedTypes[fieldName];
  
  if (!mimetype || !extname) {
    return cb(new Error(`Invalid field name: ${fieldName}`), false);
  }
  
  const isValid = mimetype.test(file.mimetype) && extname.test(path.extname(file.originalname).toLowerCase());
  
  if (isValid) {
    return cb(null, true);
  } else {
    return cb(new Error(`Invalid file type. Allowed types: ${allowedTypes[fieldName]}`), false);
  }
};

// Multer configuration
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max file size
    files: 50, // Max 50 files per upload
  },
});

// Error handler for multer
const handleUploadError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Multer-specific errors
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        message: 'File too large. Maximum size is 10MB.',
      });
    }
    
    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        success: false,
        message: 'Too many files. Maximum is 50 files.',
      });
    }
    
    if (err.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({
        success: false,
        message: 'Unexpected field name.',
      });
    }
    
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }
  
  if (err) {
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }
  
  next();
};

// Cleanup temporary files
const cleanupTempFiles = (files) => {
  if (!files) return;
  
  const filesArray = Array.isArray(files) ? files : [files];
  
  filesArray.forEach(file => {
    if (file && file.path) {
      fs.unlink(file.path, (err) => {
        if (err) console.error('Error deleting temp file:', err);
      });
    }
  });
};

module.exports = {
  upload,
  handleUploadError,
  cleanupTempFiles,
};
