/**
 * Validation Middleware
 * Input validation using express-validator
 */

const { body, param, query, validationResult } = require('express-validator');

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map(err => ({
        field: err.path,
        message: err.msg,
      })),
    });
  }
  
  next();
};

// Auth validations
const loginValidation = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  handleValidationErrors,
];

const registerValidation = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters'),
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  body('role')
    .optional()
    .isIn(['admin', 'editor', 'viewer'])
    .withMessage('Invalid role'),
  handleValidationErrors,
];

// Student validations
const createStudentValidation = [
  body('firstName')
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('First name is required and must be less than 50 characters'),
  body('lastName')
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('Last name is required and must be less than 50 characters'),
  body('class')
    .trim()
    .notEmpty()
    .withMessage('Class is required'),
  body('section')
    .trim()
    .notEmpty()
    .withMessage('Section is required'),
  body('rollNumber')
    .trim()
    .notEmpty()
    .withMessage('Roll number is required'),
  body('email')
    .optional()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('phone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Phone number must be less than 20 characters'),
  body('bloodGroup')
    .optional()
    .trim()
    .toUpperCase()
    .isIn(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'])
    .withMessage('Invalid blood group'),
  handleValidationErrors,
];

const updateStudentValidation = [
  param('id')
    .isMongoId()
    .withMessage('Invalid student ID'),
  body('firstName')
    .optional()
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('First name must be less than 50 characters'),
  body('lastName')
    .optional()
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('Last name must be less than 50 characters'),
  body('email')
    .optional()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  handleValidationErrors,
];

const studentIdValidation = [
  param('id')
    .isMongoId()
    .withMessage('Invalid student ID'),
  handleValidationErrors,
];

const bulkStudentsValidation = [
  body('students')
    .isArray({ min: 1 })
    .withMessage('Students array is required and must not be empty'),
  body('students.*.firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required for all students'),
  body('students.*.lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required for all students'),
  body('students.*.class')
    .trim()
    .notEmpty()
    .withMessage('Class is required for all students'),
  body('students.*.section')
    .trim()
    .notEmpty()
    .withMessage('Section is required for all students'),
  handleValidationErrors,
];

// Template validations
const createTemplateValidation = [
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Template name is required and must be less than 100 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description must be less than 500 characters'),
  body('dimensions.width')
    .optional()
    .isInt({ min: 100, max: 2000 })
    .withMessage('Width must be between 100 and 2000 pixels'),
  body('dimensions.height')
    .optional()
    .isInt({ min: 100, max: 2000 })
    .withMessage('Height must be between 100 and 2000 pixels'),
  handleValidationErrors,
];

const templateIdValidation = [
  param('id')
    .isMongoId()
    .withMessage('Invalid template ID'),
  handleValidationErrors,
];

// Query validations
const paginationValidation = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  query('search')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Search query must be less than 100 characters'),
  handleValidationErrors,
];

const filterValidation = [
  query('class')
    .optional()
    .trim(),
  query('section')
    .optional()
    .trim()
    .toUpperCase(),
  query('academicYear')
    .optional()
    .trim(),
  handleValidationErrors,
];

// ID Card generation validation
const generateIdCardValidation = [
  body('studentIds')
    .isArray({ min: 1 })
    .withMessage('Student IDs array is required'),
  body('studentIds.*')
    .isMongoId()
    .withMessage('Invalid student ID in array'),
  body('templateId')
    .optional()
    .isMongoId()
    .withMessage('Invalid template ID'),
  body('format')
    .optional()
    .isIn(['pdf', 'png', 'jpg'])
    .withMessage('Format must be pdf, png, or jpg'),
  handleValidationErrors,
];

// Settings validation
const updateSettingsValidation = [
  body('schoolInfo.name')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('School name must be less than 200 characters'),
  body('idCardSettings.dpi')
    .optional()
    .isInt({ min: 72, max: 600 })
    .withMessage('DPI must be between 72 and 600'),
  handleValidationErrors,
];

module.exports = {
  handleValidationErrors,
  loginValidation,
  registerValidation,
  createStudentValidation,
  updateStudentValidation,
  studentIdValidation,
  bulkStudentsValidation,
  createTemplateValidation,
  templateIdValidation,
  paginationValidation,
  filterValidation,
  generateIdCardValidation,
  updateSettingsValidation,
};
