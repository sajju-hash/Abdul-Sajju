/**
 * Create New Admin User Script
 * Run: node create-admin.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const { User } = require('./models');

const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

async function createAdmin() {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/school_id_cards';
    await mongoose.connect(mongoURI);
    console.log('\n✅ Connected to MongoDB\n');

    console.log('========================================');
    console.log('   Create New Admin User');
    console.log('========================================\n');

    const name = await ask('Full Name: ');
    const email = await ask('Email: ');
    const password = await ask('Password (min 6 chars): ');
    const role = await ask('Role (admin/editor/viewer) [admin]: ') || 'admin';

    // Check if email exists
    const existing = await User.findOne({ email });
    if (existing) {
      console.log('\n❌ Error: This email already exists!');
      console.log('   Use reset-password.js to reset password instead.\n');
      process.exit(1);
    }

    // Create user
    const user = await User.create({
      name: name || 'New Admin',
      email: email,
      password: password || 'admin123',
      role: role,
    });

    console.log('\n========================================');
    console.log('✅ Admin user created successfully!');
    console.log('========================================');
    console.log(`   Name:     ${user.name}`);
    console.log(`   Email:    ${user.email}`);
    console.log(`   Password: ${password || 'admin123'}`);
    console.log(`   Role:     ${user.role}`);
    console.log('========================================');
    console.log('\nYou can now login at: http://localhost:3000/login\n');

  } catch (error) {
    console.error('\n❌ Error:', error.message);
  } finally {
    await mongoose.disconnect();
    rl.close();
  }
}

createAdmin();
