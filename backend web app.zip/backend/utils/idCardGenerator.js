/**
 * ID Card Generator Utility
 * Generate ID cards as PNG/PDF using Puppeteer and Canvas
 */

const puppeteer = require('puppeteer');
const QRCode = require('qrcode');
const bwipjs = require('bwip-js');
const path = require('path');
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const { v4: uuidv4 } = require('uuid');

// ID Card dimensions (standard credit card size at 300 DPI)
const DEFAULT_WIDTH = 600;  // ~51mm
const DEFAULT_HEIGHT = 378; // ~32mm

/**
 * Generate QR Code as data URL
 * @param {String} data - Data to encode
 * @param {Object} options - QR code options
 * @returns {Promise<String>} Data URL of QR code
 */
const generateQRCode = async (data, options = {}) => {
  try {
    const qrOptions = {
      width: options.width || 100,
      margin: options.margin || 2,
      color: {
        dark: options.color || '#000000',
        light: options.bgColor || '#FFFFFF',
      },
      errorCorrectionLevel: options.errorCorrectionLevel || 'M',
    };
    
    return await QRCode.toDataURL(data, qrOptions);
  } catch (error) {
    console.error('QR Code generation error:', error);
    throw new Error('Failed to generate QR code');
  }
};

/**
 * Generate Barcode as data URL
 * @param {String} data - Data to encode
 * @param {Object} options - Barcode options
 * @returns {Promise<String>} Data URL of barcode
 */
const generateBarcode = async (data, options = {}) => {
  try {
    const barcodeOptions = {
      bcid: options.format || 'code128', // Barcode type
      text: data,
      scale: options.scale || 2,
      height: options.height || 50,
      includetext: options.displayValue !== false,
      textxalign: 'center',
    };
    
    const png = await bwipjs.toBuffer(barcodeOptions);
    return `data:image/png;base64,${png.toString('base64')}`;
  } catch (error) {
    console.error('Barcode generation error:', error);
    throw new Error('Failed to generate barcode');
  }
};

/**
 * Generate HTML template for ID card
 * @param {Object} student - Student data
 * @param {Object} template - Template configuration
 * @param {Object} settings - Application settings
 * @returns {Promise<String>} HTML string
 */
const generateIdCardHTML = async (student, template, settings = {}) => {
  const { elements, background, branding, dimensions } = template;
  const { width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT } = dimensions || {};
  
  // Generate QR code if needed
  let qrCodeDataUrl = null;
  const qrElement = elements.find(el => el.type === 'qrCode');
  if (qrElement) {
    const qrData = qrElement.field === 'profileUrl' 
      ? `${settings.baseUrl || ''}/student/${student.studentId}`
      : student.studentId;
    qrCodeDataUrl = await generateQRCode(qrData, qrElement.style);
  }
  
  // Generate barcode if needed
  let barcodeDataUrl = null;
  const barcodeElement = elements.find(el => el.type === 'barcode');
  if (barcodeElement) {
    barcodeDataUrl = await generateBarcode(student.studentId, barcodeElement.style);
  }
  
  // Build CSS for background
  let backgroundCSS = `background-color: ${background?.color || '#ffffff'};`;
  if (background?.image) {
    backgroundCSS += `background-image: url('${background.image}'); background-size: cover; background-position: center;`;
  } else if (background?.gradient?.enabled) {
    const gradient = background.gradient;
    const gradientType = gradient.type === 'radial' ? 'radial-gradient' : 'linear-gradient';
    const gradientValue = gradient.type === 'radial' 
      ? `${gradient.colors.join(', ')}`
      : `${gradient.angle}deg, ${gradient.colors.join(', ')}`;
    backgroundCSS += `background: ${gradientType}(${gradientValue});`;
  }
  
  // Generate elements HTML
  const elementsHTML = elements.map(el => {
    const style = `
      position: absolute;
      left: ${el.x}px;
      top: ${el.y}px;
      width: ${el.width}px;
      height: ${el.height}px;
      font-size: ${el.style?.fontSize || 14}px;
      font-family: ${el.style?.fontFamily || 'Arial'}, sans-serif;
      font-weight: ${el.style?.fontWeight || 'normal'};
      font-style: ${el.style?.fontStyle || 'normal'};
      text-align: ${el.style?.textAlign || 'left'};
      color: ${el.style?.color || '#000000'};
      background-color: ${el.style?.backgroundColor || 'transparent'};
      border: ${el.style?.borderWidth || 0}px solid ${el.style?.borderColor || '#000000'};
      border-radius: ${el.style?.borderRadius || 0}px;
      opacity: ${el.style?.opacity || 1};
      transform: rotate(${el.style?.rotation || 0}deg);
      z-index: ${el.style?.zIndex || 1};
      overflow: hidden;
      display: flex;
      align-items: center;
      ${el.type === 'text' ? 'justify-content: ' + (el.style?.textAlign === 'center' ? 'center' : el.style?.textAlign === 'right' ? 'flex-end' : 'flex-start') + ';' : ''}
    `;
    
    let content = '';
    
    switch (el.type) {
      case 'text':
        if (el.field && student[el.field]) {
          content = student[el.field];
        } else if (el.content) {
          content = el.content;
        }
        return `<div style="${style}">${content}</div>`;
        
      case 'image':
        if (el.field === 'photo' && student.photo) {
          content = `<img src="${student.photo}" style="width: 100%; height: 100%; object-fit: cover;" />`;
        } else if (el.imageUrl) {
          content = `<img src="${el.imageUrl}" style="width: 100%; height: 100%; object-fit: contain;" />`;
        }
        return `<div style="${style}">${content}</div>`;
        
      case 'qrCode':
        if (qrCodeDataUrl) {
          content = `<img src="${qrCodeDataUrl}" style="width: 100%; height: 100%; object-fit: contain;" />`;
        }
        return `<div style="${style}">${content}</div>`;
        
      case 'barcode':
        if (barcodeDataUrl) {
          content = `<img src="${barcodeDataUrl}" style="width: 100%; height: 100%; object-fit: contain;" />`;
        }
        return `<div style="${style}">${content}</div>`;
        
      case 'rectangle':
        return `<div style="${style} background-color: ${el.style?.backgroundColor || '#000000'};"></div>`;
        
      case 'line':
        return `<div style="${style} background-color: ${el.style?.color || '#000000'}; height: ${el.style?.borderWidth || 1}px;"></div>`;
        
      default:
        return '';
    }
  }).join('');
  
  // Full HTML template
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        body {
          font-family: Arial, sans-serif;
        }
        .id-card {
          width: ${width}px;
          height: ${height}px;
          position: relative;
          overflow: hidden;
          ${backgroundCSS}
        }
      </style>
    </head>
    <body>
      <div class="id-card">
        ${elementsHTML}
      </div>
    </body>
    </html>
  `;
  
  return html;
};

/**
 * Generate ID card as PNG image
 * @param {Object} student - Student data
 * @param {Object} template - Template configuration
 * @param {Object} settings - Application settings
 * @returns {Promise<String>} Path to generated image
 */
const generateIdCardPNG = async (student, template, settings = {}) => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  
  try {
    const page = await browser.newPage();
    const html = await generateIdCardHTML(student, template, settings);
    
    const { width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT } = template.dimensions || {};
    
    await page.setViewport({ width, height });
    await page.setContent(html, { waitUntil: 'networkidle0' });
    
    // Generate unique filename
    const filename = `idcard_${student.studentId}_${uuidv4()}.png`;
    const outputPath = path.join(__dirname, '..', 'uploads', 'idcards', filename);
    
    await page.screenshot({
      path: outputPath,
      type: 'png',
      omitBackground: false,
    });
    
    return {
      path: outputPath,
      filename,
      url: `/uploads/idcards/${filename}`,
    };
  } finally {
    await browser.close();
  }
};

/**
 * Generate multiple ID cards as PDF
 * @param {Array} students - Array of student data
 * @param {Object} template - Template configuration
 * @param {Object} settings - Application settings
 * @param {Object} printLayout - Print layout configuration
 * @returns {Promise<String>} Path to generated PDF
 */
const generateIdCardsPDF = async (students, template, settings = {}, printLayout = {}) => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  
  try {
    const page = await browser.newPage();
    
    const { width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT } = template.dimensions || {};
    const {
      cardsPerRow = 2,
      cardsPerColumn = 5,
      margin = 10,
      spacing = 5,
    } = printLayout;
    
    // Calculate page dimensions (A4 at 96 DPI)
    const pageWidth = 794;
    const pageHeight = 1123;
    
    // Generate all ID card HTMLs
    const cardHTMLs = await Promise.all(
      students.map(student => generateIdCardHTML(student, template, settings))
    );
    
    // Build PDF HTML with grid layout
    let cardsHTML = '';
    cardHTMLs.forEach((html, index) => {
      const row = Math.floor(index / cardsPerRow);
      const col = index % cardsPerRow;
      
      cardsHTML += `
        <div class="id-card-wrapper" style="
          position: absolute;
          left: ${margin + col * (width + spacing)}px;
          top: ${margin + (row % cardsPerColumn) * (height + spacing)}px;
          width: ${width}px;
          height: ${height}px;
        ">
          ${html.replace('<!DOCTYPE html>', '').replace(/<html>|<\/html>|<head>.*<\/head>/gs, '')}
        </div>
      `;
    });
    
    const pdfHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          @page {
            size: A4;
            margin: 0;
          }
          body {
            margin: 0;
            padding: 0;
          }
          .page {
            width: ${pageWidth}px;
            height: ${pageHeight}px;
            position: relative;
            page-break-after: always;
          }
          .page:last-child {
            page-break-after: auto;
          }
        </style>
      </head>
      <body>
        ${cardsHTML}
      </body>
      </html>
    `;
    
    await page.setContent(pdfHTML, { waitUntil: 'networkidle0' });
    
    // Generate unique filename
    const filename = `idcards_batch_${uuidv4()}.pdf`;
    const outputPath = path.join(__dirname, '..', 'uploads', 'idcards', filename);
    
    await page.pdf({
      path: outputPath,
      width: `${pageWidth}px`,
      height: `${pageHeight}px`,
      printBackground: true,
    });
    
    return {
      path: outputPath,
      filename,
      url: `/uploads/idcards/${filename}`,
    };
  } finally {
    await browser.close();
  }
};

/**
 * Generate print-ready layout HTML
 * @param {Array} students - Array of student data
 * @param {Object} template - Template configuration
 * @param {Object} settings - Application settings
 * @returns {Promise<String>} HTML string for printing
 */
const generatePrintLayout = async (students, template, settings = {}) => {
  const { width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT } = template.dimensions || {};
  
  // Generate all ID card HTMLs
  const cardHTMLs = await Promise.all(
    students.map(student => generateIdCardHTML(student, template, settings))
  );
  
  const cardsHTML = cardHTMLs.map(html => `
    <div class="id-card-print" style="
      width: ${width}px;
      height: ${height}px;
      page-break-inside: avoid;
      margin: 5px;
    ">
      ${html.replace('<!DOCTYPE html>', '').replace(/<html>|<\/html>|<head>.*<\/head>/gs, '')}
    </div>
  `).join('');
  
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>ID Cards Print Layout</title>
      <style>
        @page {
          size: A4;
          margin: 10mm;
        }
        body {
          margin: 0;
          padding: 0;
          font-family: Arial, sans-serif;
        }
        .print-container {
          display: flex;
          flex-wrap: wrap;
          justify-content: flex-start;
          align-items: flex-start;
          padding: 10px;
        }
        .id-card-print {
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        @media print {
          .no-print {
            display: none !important;
          }
        }
      </style>
    </head>
    <body>
      <div class="no-print" style="
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #333;
        color: white;
        padding: 10px;
        text-align: center;
        z-index: 1000;
      ">
        <button onclick="window.print()" style="
          padding: 10px 20px;
          font-size: 16px;
          cursor: pointer;
          background: #4CAF50;
          color: white;
          border: none;
          border-radius: 4px;
        ">Print ID Cards</button>
        <span style="margin-left: 20px;">Total: ${students.length} cards</span>
      </div>
      <div style="height: 60px;"></div>
      <div class="print-container">
        ${cardsHTML}
      </div>
    </body>
    </html>
  `;
};

module.exports = {
  generateQRCode,
  generateBarcode,
  generateIdCardHTML,
  generateIdCardPNG,
  generateIdCardsPDF,
  generatePrintLayout,
  DEFAULT_WIDTH,
  DEFAULT_HEIGHT,
};
