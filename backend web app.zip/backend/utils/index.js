/**
 * Utils Index
 * Export all utilities from a single file
 */

const idCardGenerator = require('./idCardGenerator');
const excelParser = require('./excelParser');
const faceDetection = require('./faceDetection');

module.exports = {
  ...idCardGenerator,
  ...excelParser,
  ...faceDetection,
};
