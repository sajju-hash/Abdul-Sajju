/**
 * Face Detection Utility
 * Face detection and auto-cropping using face-api.js
 */

const canvas = require('canvas');
const faceapi = require('face-api.js');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');

// Configure face-api.js to use node-canvas
const { Canvas, Image, ImageData } = canvas;
faceapi.env.monkeyPatch({ Canvas, Image, ImageData });

// Path to face-api.js models
const MODELS_PATH = path.join(__dirname, '..', 'models', 'face-api');

// Model loading state
let modelsLoaded = false;

/**
 * Load face detection models
 * @returns {Promise<Boolean>} Models loaded successfully
 */
const loadModels = async () => {
  if (modelsLoaded) return true;
  
  try {
    // Check if models directory exists
    if (!fs.existsSync(MODELS_PATH)) {
      console.warn('Face-api models directory not found. Face detection will be disabled.');
      return false;
    }
    
    // Load required models
    await faceapi.nets.tinyFaceDetector.loadFromDisk(MODELS_PATH);
    await faceapi.nets.faceLandmark68Net.loadFromDisk(MODELS_PATH);
    await faceapi.nets.faceRecognitionNet.loadFromDisk(MODELS_PATH);
    
    modelsLoaded = true;
    console.log('✅ Face detection models loaded successfully');
    return true;
  } catch (error) {
    console.error('❌ Failed to load face detection models:', error.message);
    return false;
  }
};

/**
 * Detect faces in an image
 * @param {String|Buffer} imageInput - Image path or buffer
 * @returns {Promise<Array>} Array of detected faces
 */
const detectFaces = async (imageInput) => {
  try {
    // Load models if not already loaded
    const modelsReady = await loadModels();
    if (!modelsReady) {
      throw new Error('Face detection models not available');
    }
    
    // Load image
    let img;
    if (Buffer.isBuffer(imageInput)) {
      img = await canvas.loadImage(imageInput);
    } else {
      img = await canvas.loadImage(imageInput);
    }
    
    // Detect faces with landmarks
    const detections = await faceapi
      .detectAllFaces(img, new faceapi.TinyFaceDetectorOptions({
        inputSize: 512,
        scoreThreshold: 0.5,
      }))
      .withFaceLandmarks();
    
    return detections.map(detection => ({
      box: detection.detection.box,
      landmarks: detection.landmarks,
      score: detection.detection.score,
    }));
  } catch (error) {
    console.error('Face detection error:', error);
    throw error;
  }
};

/**
 * Auto-crop image to focus on face
 * @param {String|Buffer} imageInput - Image path or buffer
 * @param {Object} options - Cropping options
 * @returns {Promise<Buffer>} Cropped image buffer
 */
const autoCropFace = async (imageInput, options = {}) => {
  try {
    const {
      targetWidth = 300,
      targetHeight = 400,
      facePadding = 0.5, // Padding around face (50% of face size)
      minFaceSize = 100,
    } = options;
    
    // Detect faces
    const faces = await detectFaces(imageInput);
    
    if (faces.length === 0) {
      throw new Error('No face detected in image');
    }
    
    if (faces.length > 1) {
      console.warn('Multiple faces detected, using the largest one');
    }
    
    // Get the largest face
    const face = faces.reduce((largest, current) => 
      current.box.width * current.box.height > largest.box.width * largest.box.height 
        ? current 
        : largest
    );
    
    // Load image with sharp for processing
    let image = sharp(imageInput);
    const metadata = await image.metadata();
    
    const { width: imgWidth, height: imgHeight } = metadata;
    const { x, y, width: faceWidth, height: faceHeight } = face.box;
    
    // Calculate crop dimensions with padding
    const paddingX = faceWidth * facePadding;
    const paddingY = faceHeight * facePadding;
    
    // Calculate crop box
    let cropLeft = Math.max(0, Math.round(x - paddingX));
    let cropTop = Math.max(0, Math.round(y - paddingY));
    let cropWidth = Math.min(imgWidth - cropLeft, Math.round(faceWidth + paddingX * 2));
    let cropHeight = Math.min(imgHeight - cropTop, Math.round(faceHeight + paddingY * 2));
    
    // Maintain aspect ratio for target dimensions
    const targetAspect = targetWidth / targetHeight;
    const currentAspect = cropWidth / cropHeight;
    
    if (currentAspect > targetAspect) {
      // Image is wider, adjust width
      const newWidth = Math.round(cropHeight * targetAspect);
      cropLeft += Math.round((cropWidth - newWidth) / 2);
      cropWidth = newWidth;
    } else {
      // Image is taller, adjust height
      const newHeight = Math.round(cropWidth / targetAspect);
      cropTop += Math.round((cropHeight - newHeight) / 2);
      cropHeight = newHeight;
    }
    
    // Ensure crop box is within image bounds
    cropLeft = Math.max(0, cropLeft);
    cropTop = Math.max(0, cropTop);
    cropWidth = Math.min(imgWidth - cropLeft, cropWidth);
    cropHeight = Math.min(imgHeight - cropTop, cropHeight);
    
    // Crop and resize image
    const croppedBuffer = await image
      .extract({
        left: cropLeft,
        top: cropTop,
        width: cropWidth,
        height: cropHeight,
      })
      .resize(targetWidth, targetHeight, {
        fit: 'cover',
        position: 'center',
      })
      .jpeg({
        quality: 90,
        progressive: true,
      })
      .toBuffer();
    
    return croppedBuffer;
  } catch (error) {
    console.error('Auto-crop error:', error);
    throw error;
  }
};

/**
 * Process photo with face detection and optimization
 * @param {String|Buffer} imageInput - Image path or buffer
 * @param {Object} options - Processing options
 * @returns {Promise<Object>} Processed image info
 */
const processPhoto = async (imageInput, options = {}) => {
  try {
    const {
      targetWidth = 300,
      targetHeight = 400,
      quality = 90,
      format = 'jpeg',
      autoCrop = true,
      detectFace = true,
    } = options;
    
    let processedBuffer;
    let faceDetected = false;
    
    // Try face detection and auto-crop if enabled
    if (detectFace && autoCrop) {
      try {
        processedBuffer = await autoCropFace(imageInput, {
          targetWidth,
          targetHeight,
        });
        faceDetected = true;
      } catch (faceError) {
        console.warn('Face detection failed, falling back to center crop:', faceError.message);
        // Fall back to center crop
        processedBuffer = await centerCrop(imageInput, targetWidth, targetHeight);
      }
    } else {
      // Just resize without face detection
      processedBuffer = await sharp(imageInput)
        .resize(targetWidth, targetHeight, {
          fit: 'cover',
          position: 'center',
        })
        .toFormat(format, { quality })
        .toBuffer();
    }
    
    // Get final image info
    const metadata = await sharp(processedBuffer).metadata();
    
    return {
      buffer: processedBuffer,
      width: metadata.width,
      height: metadata.height,
      format: metadata.format,
      size: processedBuffer.length,
      faceDetected,
    };
  } catch (error) {
    console.error('Photo processing error:', error);
    throw error;
  }
};

/**
 * Center crop image to target dimensions
 * @param {String|Buffer} imageInput - Image path or buffer
 * @param {Number} targetWidth - Target width
 * @param {Number} targetHeight - Target height
 * @returns {Promise<Buffer>} Cropped image buffer
 */
const centerCrop = async (imageInput, targetWidth, targetHeight) => {
  const image = sharp(imageInput);
  const metadata = await image.metadata();
  
  const { width: imgWidth, height: imgHeight } = metadata;
  
  // Calculate crop dimensions
  const targetAspect = targetWidth / targetHeight;
  const imgAspect = imgWidth / imgHeight;
  
  let cropWidth, cropHeight, cropLeft, cropTop;
  
  if (imgAspect > targetAspect) {
    // Image is wider, crop width
    cropHeight = imgHeight;
    cropWidth = Math.round(imgHeight * targetAspect);
    cropLeft = Math.round((imgWidth - cropWidth) / 2);
    cropTop = 0;
  } else {
    // Image is taller, crop height
    cropWidth = imgWidth;
    cropHeight = Math.round(imgWidth / targetAspect);
    cropLeft = 0;
    cropTop = Math.round((imgHeight - cropHeight) / 2);
  }
  
  return await image
    .extract({
      left: cropLeft,
      top: cropTop,
      width: cropWidth,
      height: cropHeight,
    })
    .resize(targetWidth, targetHeight, {
      fit: 'fill',
    })
    .jpeg({ quality: 90 })
    .toBuffer();
};

/**
 * Compress image
 * @param {String|Buffer} imageInput - Image path or buffer
 * @param {Object} options - Compression options
 * @returns {Promise<Buffer>} Compressed image buffer
 */
const compressImage = async (imageInput, options = {}) => {
  const {
    quality = 80,
    maxWidth = 1200,
    maxHeight = 1200,
    format = 'jpeg',
  } = options;
  
  let image = sharp(imageInput);
  const metadata = await image.metadata();
  
  // Resize if too large
  if (metadata.width > maxWidth || metadata.height > maxHeight) {
    image = image.resize(maxWidth, maxHeight, {
      fit: 'inside',
      withoutEnlargement: true,
    });
  }
  
  // Convert and compress
  return await image
    .toFormat(format, { quality })
    .toBuffer();
};

/**
 * Check if image contains a face
 * @param {String|Buffer} imageInput - Image path or buffer
 * @returns {Promise<Boolean>} Image contains face
 */
const hasFace = async (imageInput) => {
  try {
    const faces = await detectFaces(imageInput);
    return faces.length > 0;
  } catch (error) {
    return false;
  }
};

module.exports = {
  loadModels,
  detectFaces,
  autoCropFace,
  processPhoto,
  centerCrop,
  compressImage,
  hasFace,
};
