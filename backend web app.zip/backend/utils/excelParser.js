/**
 * Excel Parser Utility
 * Parse Excel files and validate student data
 */

const xlsx = require('xlsx');
const fs = require('fs');
const path = require('path');

// Default column mappings (Excel column -> Student field)
const DEFAULT_COLUMN_MAPPINGS = {
  'First Name': 'firstName',
  'FirstName': 'firstName',
  'First_Name': 'firstName',
  'firstName': 'firstName',
  'first_name': 'firstName',
  
  'Last Name': 'lastName',
  'LastName': 'lastName',
  'Last_Name': 'lastName',
  'lastName': 'lastName',
  'last_name': 'lastName',
  
  'Name': 'fullName',
  'Full Name': 'fullName',
  'FullName': 'fullName',
  
  'Class': 'class',
  'class': 'class',
  'Grade': 'class',
  
  'Section': 'section',
  'section': 'section',
  'Div': 'section',
  'Division': 'section',
  
  'Roll Number': 'rollNumber',
  'RollNumber': 'rollNumber',
  'Roll_No': 'rollNumber',
  'RollNo': 'rollNumber',
  'Roll': 'rollNumber',
  
  'Student ID': 'studentId',
  'StudentID': 'studentId',
  'Student_Id': 'studentId',
  'ID': 'studentId',
  
  'Email': 'email',
  'E-mail': 'email',
  'Email Address': 'email',
  
  'Phone': 'phone',
  'Mobile': 'phone',
  'Contact': 'phone',
  'Phone Number': 'phone',
  
  'Address': 'address',
  
  'Blood Group': 'bloodGroup',
  'BloodGroup': 'bloodGroup',
  'Blood': 'bloodGroup',
  
  'Date of Birth': 'dateOfBirth',
  'DOB': 'dateOfBirth',
  'Birth Date': 'dateOfBirth',
  
  'Gender': 'gender',
  'Sex': 'gender',
  
  'Academic Year': 'academicYear',
  'AcademicYear': 'academicYear',
  'Year': 'academicYear',
  
  'Photo': 'photo',
  'Photo URL': 'photo',
  'Image': 'photo',
};

// Required fields for student
const REQUIRED_FIELDS = ['firstName', 'lastName', 'class', 'section', 'rollNumber'];

/**
 * Parse Excel file and extract student data
 * @param {String} filePath - Path to Excel file
 * @param {Object} options - Parsing options
 * @returns {Promise<Object>} Parsed data with students and errors
 */
const parseExcelFile = async (filePath, options = {}) => {
  try {
    // Read the workbook
    const workbook = xlsx.readFile(filePath);
    
    // Get the first sheet or specified sheet
    const sheetName = options.sheetName || workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    if (!worksheet) {
      throw new Error(`Sheet "${sheetName}" not found in Excel file`);
    }
    
    // Convert to JSON
    const jsonData = xlsx.utils.sheet_to_json(worksheet, {
      header: 1,
      defval: '',
      blankrows: false,
    });
    
    if (jsonData.length < 2) {
      throw new Error('Excel file must have at least a header row and one data row');
    }
    
    // Extract headers (first row)
    const headers = jsonData[0].map(h => String(h).trim());
    
    // Map headers to student fields
    const columnMapping = {};
    headers.forEach((header, index) => {
      const fieldName = DEFAULT_COLUMN_MAPPINGS[header] || header.toLowerCase().replace(/\s+/g, '_');
      columnMapping[index] = fieldName;
    });
    
    // Parse data rows
    const students = [];
    const errors = [];
    
    for (let i = 1; i < jsonData.length; i++) {
      const row = jsonData[i];
      const student = {};
      const rowErrors = [];
      
      // Map row data to student object
      headers.forEach((_, index) => {
        const fieldName = columnMapping[index];
        const value = row[index];
        
        if (value !== undefined && value !== '') {
          student[fieldName] = String(value).trim();
        }
      });
      
      // Handle full name split
      if (student.fullName && (!student.firstName || !student.lastName)) {
        const nameParts = student.fullName.split(' ');
        student.firstName = nameParts[0];
        student.lastName = nameParts.slice(1).join(' ') || '';
        delete student.fullName;
      }
      
      // Validate required fields
      REQUIRED_FIELDS.forEach(field => {
        if (!student[field] || student[field].trim() === '') {
          rowErrors.push(`Missing required field: ${field}`);
        }
      });
      
      // Validate email if provided
      if (student.email && !isValidEmail(student.email)) {
        rowErrors.push('Invalid email format');
      }
      
      // Validate date of birth if provided
      if (student.dateOfBirth) {
        const parsedDate = parseDate(student.dateOfBirth);
        if (parsedDate) {
          student.dateOfBirth = parsedDate;
        } else {
          rowErrors.push('Invalid date of birth format');
        }
      }
      
      // Validate blood group if provided
      if (student.bloodGroup) {
        student.bloodGroup = student.bloodGroup.toUpperCase();
        const validBloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
        if (!validBloodGroups.includes(student.bloodGroup)) {
          rowErrors.push('Invalid blood group');
        }
      }
      
      // Validate gender if provided
      if (student.gender) {
        student.gender = student.gender.toLowerCase();
        const validGenders = ['male', 'female', 'other'];
        if (!validGenders.includes(student.gender)) {
          rowErrors.push('Invalid gender (must be male, female, or other)');
        }
      }
      
      // Add row number for error tracking
      student._rowNumber = i + 1;
      
      if (rowErrors.length > 0) {
        errors.push({
          row: i + 1,
          data: student,
          errors: rowErrors,
        });
      } else {
        students.push(student);
      }
    }
    
    return {
      success: true,
      totalRows: jsonData.length - 1,
      validStudents: students.length,
      errorCount: errors.length,
      students,
      errors,
      headers,
    };
    
  } catch (error) {
    return {
      success: false,
      message: error.message,
      error: error.toString(),
    };
  }
};

/**
 * Validate email format
 * @param {String} email - Email to validate
 * @returns {Boolean} Is valid email
 */
const isValidEmail = (email) => {
  const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  return emailRegex.test(email);
};

/**
 * Parse date from various formats
 * @param {String} dateStr - Date string
 * @returns {Date|null} Parsed date or null
 */
const parseDate = (dateStr) => {
  if (!dateStr) return null;
  
  // Try different date formats
  const formats = [
    // Excel serial date
    (str) => {
      const serial = parseFloat(str);
      if (!isNaN(serial) && serial > 30000) {
        // Excel dates are serial numbers from 1900-01-01
        const epoch = new Date(1899, 11, 30);
        return new Date(epoch.getTime() + serial * 24 * 60 * 60 * 1000);
      }
      return null;
    },
    // Standard date parsing
    (str) => {
      const date = new Date(str);
      return isNaN(date.getTime()) ? null : date;
    },
    // DD/MM/YYYY format
    (str) => {
      const parts = str.split(/[/-]/);
      if (parts.length === 3) {
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const year = parseInt(parts[2], 10);
        const date = new Date(year, month, day);
        return isNaN(date.getTime()) ? null : date;
      }
      return null;
    },
    // MM/DD/YYYY format
    (str) => {
      const parts = str.split(/[/-]/);
      if (parts.length === 3) {
        const month = parseInt(parts[0], 10) - 1;
        const day = parseInt(parts[1], 10);
        const year = parseInt(parts[2], 10);
        const date = new Date(year, month, day);
        return isNaN(date.getTime()) ? null : date;
      }
      return null;
    },
  ];
  
  for (const format of formats) {
    const result = format(String(dateStr));
    if (result) return result;
  }
  
  return null;
};

/**
 * Generate sample Excel template
 * @param {String} outputPath - Output file path
 * @returns {Promise<String>} Path to generated template
 */
const generateTemplate = async (outputPath) => {
  const headers = [
    'First Name',
    'Last Name',
    'Class',
    'Section',
    'Roll Number',
    'Email',
    'Phone',
    'Address',
    'Blood Group',
    'Date of Birth',
    'Gender',
    'Academic Year',
  ];
  
  const sampleData = [
    [
      'John',
      'Doe',
      '10',
      'A',
      '001',
      'john.doe@example.com',
      '1234567890',
      '123 Main St',
      'O+',
      '2008-05-15',
      'Male',
      '2024',
    ],
    [
      'Jane',
      'Smith',
      '10',
      'A',
      '002',
      'jane.smith@example.com',
      '0987654321',
      '456 Oak Ave',
      'A+',
      '2008-08-22',
      'Female',
      '2024',
    ],
  ];
  
  const worksheet = xlsx.utils.aoa_to_sheet([headers, ...sampleData]);
  
  // Set column widths
  const colWidths = headers.map(() => ({ wch: 20 }));
  worksheet['!cols'] = colWidths;
  
  const workbook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(workbook, worksheet, 'Students');
  
  const templatePath = outputPath || path.join(__dirname, '..', 'uploads', 'temp', 'student_template.xlsx');
  xlsx.writeFile(workbook, templatePath);
  
  return templatePath;
};

/**
 * Export students to Excel
 * @param {Array} students - Array of student objects
 * @param {String} outputPath - Output file path
 * @returns {Promise<String>} Path to generated file
 */
const exportToExcel = async (students, outputPath) => {
  if (!students || students.length === 0) {
    throw new Error('No students to export');
  }
  
  // Define columns to export
  const columns = [
    { header: 'Student ID', key: 'studentId' },
    { header: 'First Name', key: 'firstName' },
    { header: 'Last Name', key: 'lastName' },
    { header: 'Class', key: 'class' },
    { header: 'Section', key: 'section' },
    { header: 'Roll Number', key: 'rollNumber' },
    { header: 'Email', key: 'email' },
    { header: 'Phone', key: 'phone' },
    { header: 'Address', key: 'address' },
    { header: 'Blood Group', key: 'bloodGroup' },
    { header: 'Date of Birth', key: 'dateOfBirth' },
    { header: 'Gender', key: 'gender' },
    { header: 'Academic Year', key: 'academicYear' },
    { header: 'Photo Status', key: 'photoStatus' },
    { header: 'ID Card Generated', key: 'idCardGenerated' },
  ];
  
  // Prepare data
  const headers = columns.map(col => col.header);
  const data = students.map(student => 
    columns.map(col => {
      const value = student[col.key];
      if (value === null || value === undefined) return '';
      if (col.key === 'dateOfBirth' && value instanceof Date) {
        return value.toISOString().split('T')[0];
      }
      if (col.key === 'idCardGenerated') {
        return value ? 'Yes' : 'No';
      }
      return String(value);
    })
  );
  
  const worksheet = xlsx.utils.aoa_to_sheet([headers, ...data]);
  
  // Set column widths
  worksheet['!cols'] = columns.map(() => ({ wch: 20 }));
  
  const workbook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(workbook, worksheet, 'Students');
  
  xlsx.writeFile(workbook, outputPath);
  
  return outputPath;
};

module.exports = {
  parseExcelFile,
  generateTemplate,
  exportToExcel,
  REQUIRED_FIELDS,
  DEFAULT_COLUMN_MAPPINGS,
};
