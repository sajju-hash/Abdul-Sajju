/**
 * ID Card Controller
 * Handle ID card generation and export
 */

const { Student, Template } = require('../models');
const {
  generateIdCardPNG,
  generateIdCardsPDF,
  generatePrintLayout,
  generateQRCode,
  generateBarcode,
} = require('../utils/idCardGenerator');
const path = require('path');
const fs = require('fs');

/**
 * Generate single ID card
 * POST /api/idcards/generate
 */
const generateIdCard = async (req, res) => {
  try {
    const { studentId, templateId, format = 'png' } = req.body;
    
    // Get student
    const student = await Student.findById(studentId);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    // Get template
    let template;
    if (templateId) {
      template = await Template.findById(templateId);
    }
    
    if (!template) {
      template = await Template.findOne({ isDefault: true, isActive: true });
    }
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'No template found',
      });
    }
    
    // Generate ID card
    const result = await generateIdCardPNG(student, template, {
      baseUrl: `${req.protocol}://${req.get('host')}`,
    });
    
    // Update student record
    student.idCardGenerated = true;
    student.idCardUrl = result.url;
    await student.save();
    
    // Increment template usage
    await template.incrementUsage();
    
    res.status(200).json({
      success: true,
      message: 'ID card generated successfully',
      data: {
        student: student.toFormattedJSON(),
        downloadUrl: result.url,
        filename: result.filename,
      },
    });
  } catch (error) {
    console.error('Generate ID card error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate ID card',
      error: error.message,
    });
  }
};

/**
 * Generate bulk ID cards
 * POST /api/idcards/generate-bulk
 */
const generateBulkIdCards = async (req, res) => {
  try {
    const { studentIds, templateId, format = 'pdf' } = req.body;
    
    if (!studentIds || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Student IDs array is required',
      });
    }
    
    // Get students
    const students = await Student.find({
      _id: { $in: studentIds },
      isActive: true,
    });
    
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No students found',
      });
    }
    
    // Get template
    let template;
    if (templateId) {
      template = await Template.findById(templateId);
    }
    
    if (!template) {
      template = await Template.findOne({ isDefault: true, isActive: true });
    }
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'No template found',
      });
    }
    
    let result;
    
    if (format === 'pdf') {
      // Generate PDF with multiple cards
      result = await generateIdCardsPDF(
        students,
        template,
        { baseUrl: `${req.protocol}://${req.get('host')}` },
        template.idCardSettings?.printLayout
      );
    } else {
      // Generate individual PNGs
      const generatedCards = [];
      for (const student of students) {
        const cardResult = await generateIdCardPNG(student, template, {
          baseUrl: `${req.protocol}://${req.get('host')}`,
        });
        
        student.idCardGenerated = true;
        student.idCardUrl = cardResult.url;
        await student.save();
        
        generatedCards.push({
          studentId: student._id,
          downloadUrl: cardResult.url,
          filename: cardResult.filename,
        });
      }
      
      result = {
        cards: generatedCards,
        count: generatedCards.length,
      };
    }
    
    // Increment template usage
    await template.incrementUsage();
    
    res.status(200).json({
      success: true,
      message: `Generated ${students.length} ID cards`,
      data: {
        format,
        downloadUrl: result.url || null,
        filename: result.filename || null,
        cards: result.cards || null,
        count: result.count || students.length,
      },
    });
  } catch (error) {
    console.error('Generate bulk ID cards error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate ID cards',
      error: error.message,
    });
  }
};

/**
 * Generate ID cards for class/section
 * POST /api/idcards/generate-by-class
 */
const generateByClass = async (req, res) => {
  try {
    const { class: className, section, academicYear, templateId } = req.body;
    
    const query = { isActive: true };
    if (className) query.class = className;
    if (section) query.section = section.toUpperCase();
    if (academicYear) query.academicYear = academicYear;
    
    const students = await Student.find(query);
    
    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No students found for the given criteria',
      });
    }
    
    // Get template
    let template;
    if (templateId) {
      template = await Template.findById(templateId);
    }
    
    if (!template) {
      template = await Template.findOne({ isDefault: true, isActive: true });
    }
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'No template found',
      });
    }
    
    // Generate PDF
    const result = await generateIdCardsPDF(
      students,
      template,
      { baseUrl: `${req.protocol}://${req.get('host')}` },
      template.idCardSettings?.printLayout
    );
    
    // Update students
    await Student.updateMany(
      query,
      { idCardGenerated: true, idCardUrl: result.url }
    );
    
    // Increment template usage
    await template.incrementUsage();
    
    res.status(200).json({
      success: true,
      message: `Generated ${students.length} ID cards`,
      data: {
        downloadUrl: result.url,
        filename: result.filename,
        count: students.length,
      },
    });
  } catch (error) {
    console.error('Generate by class error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate ID cards',
      error: error.message,
    });
  }
};

/**
 * Get print layout HTML
 * POST /api/idcards/print-layout
 */
const getPrintLayout = async (req, res) => {
  try {
    const { studentIds, templateId } = req.body;
    
    if (!studentIds || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Student IDs array is required',
      });
    }
    
    // Get students
    const students = await Student.find({
      _id: { $in: studentIds },
      isActive: true,
    });
    
    // Get template
    let template;
    if (templateId) {
      template = await Template.findById(templateId);
    }
    
    if (!template) {
      template = await Template.findOne({ isDefault: true, isActive: true });
    }
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'No template found',
      });
    }
    
    // Generate print layout HTML
    const html = await generatePrintLayout(students, template, {
      baseUrl: `${req.protocol}://${req.get('host')}`,
    });
    
    res.status(200).json({
      success: true,
      data: {
        html,
        count: students.length,
      },
    });
  } catch (error) {
    console.error('Print layout error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate print layout',
      error: error.message,
    });
  }
};

/**
 * Preview ID card (returns HTML)
 * POST /api/idcards/preview
 */
const previewIdCard = async (req, res) => {
  try {
    const { studentId, templateId } = req.body;
    
    // Get student
    const student = await Student.findById(studentId);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    // Get template
    let template;
    if (templateId) {
      template = await Template.findById(templateId);
    }
    
    if (!template) {
      template = await Template.findOne({ isDefault: true, isActive: true });
    }
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'No template found',
      });
    }
    
    // Generate preview HTML
    const { generateIdCardHTML } = require('../utils/idCardGenerator');
    const html = await generateIdCardHTML(student, template, {
      baseUrl: `${req.protocol}://${req.get('host')}`,
    });
    
    res.status(200).json({
      success: true,
      data: {
        html,
        student: student.toFormattedJSON(),
        template: {
          id: template._id,
          name: template.name,
          dimensions: template.dimensions,
        },
      },
    });
  } catch (error) {
    console.error('Preview error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate preview',
      error: error.message,
    });
  }
};

/**
 * Generate QR code for student
 * POST /api/idcards/qr-code
 */
const generateStudentQRCode = async (req, res) => {
  try {
    const { studentId, size = 200 } = req.body;
    
    const student = await Student.findById(studentId);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    const qrData = `${req.protocol}://${req.get('host')}/student/${student.studentId}`;
    const qrCodeDataUrl = await generateQRCode(qrData, { width: size });
    
    // Update student with QR code
    student.qrCode = qrCodeDataUrl;
    await student.save();
    
    res.status(200).json({
      success: true,
      data: {
        qrCode: qrCodeDataUrl,
        studentId: student.studentId,
      },
    });
  } catch (error) {
    console.error('QR code error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate QR code',
      error: error.message,
    });
  }
};

/**
 * Generate barcode for student
 * POST /api/idcards/barcode
 */
const generateStudentBarcode = async (req, res) => {
  try {
    const { studentId, width = 2, height = 50 } = req.body;
    
    const student = await Student.findById(studentId);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    const barcodeDataUrl = await generateBarcode(student.studentId, {
      scale: width,
      height,
    });
    
    // Update student with barcode
    student.barcode = barcodeDataUrl;
    await student.save();
    
    res.status(200).json({
      success: true,
      data: {
        barcode: barcodeDataUrl,
        studentId: student.studentId,
      },
    });
  } catch (error) {
    console.error('Barcode error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate barcode',
      error: error.message,
    });
  }
};

/**
 * Download ID card file
 * GET /api/idcards/download/:filename
 */
const downloadIdCard = async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Security: prevent directory traversal
    const safeFilename = path.basename(filename);
    const filePath = path.join(__dirname, '..', 'uploads', 'idcards', safeFilename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        message: 'File not found',
      });
    }
    
    res.download(filePath, safeFilename);
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to download file',
      error: error.message,
    });
  }
};

module.exports = {
  generateIdCard,
  generateBulkIdCards,
  generateByClass,
  getPrintLayout,
  previewIdCard,
  generateStudentQRCode,
  generateStudentBarcode,
  downloadIdCard,
};
