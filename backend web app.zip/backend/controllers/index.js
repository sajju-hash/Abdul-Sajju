/**
 * Controllers Index
 * Export all controllers from a single file
 */

const authController = require('./auth.controller');
const studentController = require('./student.controller');
const templateController = require('./template.controller');
const photoController = require('./photo.controller');
const idCardController = require('./idcard.controller');
const dashboardController = require('./dashboard.controller');
const superAdminController = require('./superadmin.controller');

module.exports = {
  authController,
  studentController,
  templateController,
  photoController,
  idCardController,
  dashboardController,
  superAdminController,
};
