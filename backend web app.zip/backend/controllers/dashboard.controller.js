/**
 * Dashboard Controller
 * Handle dashboard statistics and overview
 */

const { Student, Template, User } = require('../models');

/**
 * Get dashboard statistics
 * GET /api/dashboard/stats
 */
const getStats = async (req, res) => {
  try {
    // Total students
    const totalStudents = await Student.countDocuments({ isActive: true });
    
    // Students by class
    const studentsByClass = await Student.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$class', count: { $sum: 1 } } },
      { $sort: { _id: 1 } },
    ]);
    
    // Students by section
    const studentsBySection = await Student.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$section', count: { $sum: 1 } } },
      { $sort: { _id: 1 } },
    ]);
    
    // Photo statistics
    const photoStats = await Student.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: '$photoStatus',
          count: { $sum: 1 },
        },
      },
    ]);
    
    // ID card generation statistics
    const idCardStats = {
      generated: await Student.countDocuments({ isActive: true, idCardGenerated: true }),
      pending: await Student.countDocuments({ isActive: true, idCardGenerated: false }),
    };
    
    // Recent students (last 7 days)
    const lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);
    
    const recentStudents = await Student.countDocuments({
      isActive: true,
      createdAt: { $gte: lastWeek },
    });
    
    // Total templates
    const totalTemplates = await Template.countDocuments({ isActive: true });
    
    // Default template
    const defaultTemplate = await Template.findOne({
      isDefault: true,
      isActive: true,
    }).select('name category');
    
    // Recent activity (last 5 students added)
    const recentActivity = await Student.find({ isActive: true })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('firstName lastName class section photoStatus createdAt');
    
    res.status(200).json({
      success: true,
      data: {
        overview: {
          totalStudents,
          totalTemplates,
          recentStudents,
          idCardsGenerated: idCardStats.generated,
          idCardsPending: idCardStats.pending,
        },
        studentsByClass: studentsByClass.map(item => ({
          class: item._id,
          count: item.count,
        })),
        studentsBySection: studentsBySection.map(item => ({
          section: item._id,
          count: item.count,
        })),
        photoStats: photoStats.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
        idCardStats,
        defaultTemplate: defaultTemplate || null,
        recentActivity: recentActivity.map(student => ({
          id: student._id,
          name: `${student.firstName} ${student.lastName}`,
          class: student.class,
          section: student.section,
          photoStatus: student.photoStatus,
          createdAt: student.createdAt,
        })),
      },
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get dashboard statistics',
      error: error.message,
    });
  }
};

/**
 * Get recent students
 * GET /api/dashboard/recent-students
 */
const getRecentStudents = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    
    const students = await Student.find({ isActive: true })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .select('firstName lastName class section rollNumber photo photoStatus idCardGenerated createdAt');
    
    res.status(200).json({
      success: true,
      data: {
        students: students.map(s => ({
          id: s._id,
          name: `${s.firstName} ${s.lastName}`,
          class: s.class,
          section: s.section,
          rollNumber: s.rollNumber,
          photo: s.photo,
          photoStatus: s.photoStatus,
          idCardGenerated: s.idCardGenerated,
          createdAt: s.createdAt,
        })),
      },
    });
  } catch (error) {
    console.error('Get recent students error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get recent students',
      error: error.message,
    });
  }
};

/**
 * Get students needing attention
 * GET /api/dashboard/attention-needed
 */
const getAttentionNeeded = async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    
    // Students without photos
    const withoutPhotos = await Student.find({
      isActive: true,
      $or: [
        { photo: null },
        { photo: '' },
        { photoStatus: 'pending' },
      ],
    })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .select('firstName lastName class section rollNumber createdAt');
    
    // Students without ID cards
    const withoutIdCards = await Student.find({
      isActive: true,
      idCardGenerated: false,
      photo: { $ne: null },
    })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .select('firstName lastName class section rollNumber photo createdAt');
    
    res.status(200).json({
      success: true,
      data: {
        withoutPhotos: {
          count: await Student.countDocuments({
            isActive: true,
            $or: [
              { photo: null },
              { photo: '' },
              { photoStatus: 'pending' },
            ],
          }),
          students: withoutPhotos.map(s => ({
            id: s._id,
            name: `${s.firstName} ${s.lastName}`,
            class: s.class,
            section: s.section,
            rollNumber: s.rollNumber,
            createdAt: s.createdAt,
          })),
        },
        withoutIdCards: {
          count: await Student.countDocuments({
            isActive: true,
            idCardGenerated: false,
            photo: { $ne: null },
          }),
          students: withoutIdCards.map(s => ({
            id: s._id,
            name: `${s.firstName} ${s.lastName}`,
            class: s.class,
            section: s.section,
            rollNumber: s.rollNumber,
            photo: s.photo,
            createdAt: s.createdAt,
          })),
        },
      },
    });
  } catch (error) {
    console.error('Get attention needed error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get attention needed data',
      error: error.message,
    });
  }
};

/**
 * Get activity summary
 * GET /api/dashboard/activity
 */
const getActivitySummary = async (req, res) => {
  try {
    // Daily student additions (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const dailyAdditions = await Student.aggregate([
      {
        $match: {
          isActive: true,
          createdAt: { $gte: thirtyDaysAgo },
        },
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' },
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': -1, '_id.month': -1, '_id.day': -1 } },
      { $limit: 30 },
    ]);
    
    // Monthly statistics
    const monthlyStats = await Student.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': -1, '_id.month': -1 } },
      { $limit: 12 },
    ]);
    
    res.status(200).json({
      success: true,
      data: {
        dailyAdditions: dailyAdditions.map(item => ({
          date: `${item._id.year}-${String(item._id.month).padStart(2, '0')}-${String(item._id.day).padStart(2, '0')}`,
          count: item.count,
        })),
        monthlyStats: monthlyStats.map(item => ({
          month: `${item._id.year}-${String(item._id.month).padStart(2, '0')}`,
          count: item.count,
        })),
      },
    });
  } catch (error) {
    console.error('Get activity summary error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get activity summary',
      error: error.message,
    });
  }
};

module.exports = {
  getStats,
  getRecentStudents,
  getAttentionNeeded,
  getActivitySummary,
};
