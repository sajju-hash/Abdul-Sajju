/**
 * Super Admin Controller
 * Handle super admin operations
 */

const { School, User, Student, Template } = require('../models');

const getAllSchools = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', status = '' } = req.query;
    
    const query = {};
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    if (status) query.status = status;
    
    const schools = await School.find(query)
      .populate('adminId', 'name email')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    
    const total = await School.countDocuments(query);
    
    const stats = {
      total: await School.countDocuments(),
      active: await School.countDocuments({ status: 'active' }),
      trial: await School.countDocuments({ status: 'trial' }),
      suspended: await School.countDocuments({ status: 'suspended' }),
    };
    
    res.status(200).json({
      success: true,
      data: {
        schools,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
        stats,
      },
    });
  } catch (error) {
    console.error('Get schools error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

const getSchoolById = async (req, res) => {
  try {
    const school = await School.findById(req.params.id)
      .populate('adminId', 'name email');
    
    if (!school) {
      return res.status(404).json({ success: false, message: 'School not found' });
    }
    
    res.status(200).json({ success: true, data: { school } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const createSchool = async (req, res) => {
  try {
    const {
      name, email, phone, address, city, state, country, pincode,
      adminName, adminEmail, adminPassword,
      plan, maxStudents, maxUsers, maxTemplates, subscriptionDays,
    } = req.body;
    
    // Check if admin email already exists
    const existingUser = await User.findOne({ email: adminEmail });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'Admin email already exists' });
    }
    
    // Create admin user
    const admin = await User.create({
      name: adminName,
      email: adminEmail,
      password: adminPassword,
      role: 'admin',
    });
    
    // Create school
    const subscriptionExpiry = new Date();
    subscriptionExpiry.setDate(subscriptionExpiry.getDate() + (subscriptionDays || 30));
    
    const school = await School.create({
      name,
      email,
      phone,
      address,
      city,
      state,
      country,
      pincode,
      adminId: admin._id,
      plan: plan || 'free',
      status: 'active',
      maxStudents: maxStudents || 50,
      maxUsers: maxUsers || 2,
      maxTemplates: maxTemplates || 2,
      subscriptionExpiry,
    });
    
    // Update admin with schoolId
    admin.schoolId = school._id;
    await admin.save();
    
    res.status(201).json({
      success: true,
      message: 'School created successfully',
      data: { school, admin: admin.toPublicJSON() },
    });
  } catch (error) {
    console.error('Create school error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateSchool = async (req, res) => {
  try {
    const { status, plan, maxStudents, maxUsers, maxTemplates, subscriptionExpiry } = req.body;
    
    const school = await School.findByIdAndUpdate(
      req.params.id,
      { status, plan, maxStudents, maxUsers, maxTemplates, subscriptionExpiry },
      { new: true, runValidators: true }
    );
    
    if (!school) {
      return res.status(404).json({ success: false, message: 'School not found' });
    }
    
    res.status(200).json({ success: true, message: 'School updated', data: { school } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const deleteSchool = async (req, res) => {
  try {
    const school = await School.findByIdAndDelete(req.params.id);
    if (!school) {
      return res.status(404).json({ success: false, message: 'School not found' });
    }
    
    // Delete associated admin
    await User.findByIdAndDelete(school.adminId);
    
    res.status(200).json({ success: true, message: 'School deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getDashboardStats = async (req, res) => {
  try {
    const stats = {
      schools: {
        total: await School.countDocuments(),
        active: await School.countDocuments({ status: 'active' }),
        trial: await School.countDocuments({ status: 'trial' }),
        suspended: await School.countDocuments({ status: 'suspended' }),
        inactive: await School.countDocuments({ status: 'inactive' }),
      },
      users: {
        total: await User.countDocuments(),
        admins: await User.countDocuments({ role: 'admin' }),
        superadmins: await User.countDocuments({ role: 'superadmin' }),
      },
      revenue: '$12,450', // Calculate from active subscriptions
    };
    
    const recentSchools = await School.find()
      .populate('adminId', 'name email')
      .sort({ createdAt: -1 })
      .limit(5);
    
    res.status(200).json({ success: true, data: { stats, recentSchools } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getAllSchools,
  getSchoolById,
  createSchool,
  updateSchool,
  deleteSchool,
  getDashboardStats,
};
