/**
 * Photo Controller
 * Handle photo uploads, camera capture, and face detection
 */

const { Student } = require('../models');
const { processPhoto, hasFace } = require('../utils/faceDetection');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const sharp = require('sharp');

// Upload directory
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads', 'photos');

/**
 * Upload single photo
 * POST /api/photos/upload
 */
const uploadPhoto = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No photo uploaded',
      });
    }
    
    const { studentId, autoCrop = 'true', detectFace = 'true' } = req.body;
    
    const filePath = req.file.path;
    const originalName = req.file.originalname;
    
    // Process photo
    let processedImage;
    try {
      processedImage = await processPhoto(filePath, {
        targetWidth: 300,
        targetHeight: 400,
        quality: 90,
        autoCrop: autoCrop === 'true',
        detectFace: detectFace === 'true',
      });
    } catch (processError) {
      // If processing fails, use original file
      console.warn('Photo processing failed, using original:', processError.message);
      const buffer = fs.readFileSync(filePath);
      processedImage = {
        buffer,
        width: 300,
        height: 400,
        format: 'jpeg',
        size: buffer.length,
        faceDetected: false,
      };
    }
    
    // Generate unique filename
    const filename = `${uuidv4()}.jpg`;
    const outputPath = path.join(UPLOAD_DIR, filename);
    
    // Save processed image
    fs.writeFileSync(outputPath, processedImage.buffer);
    
    // Clean up original temp file
    fs.unlinkSync(filePath);
    
    // If studentId provided, update student record
    let student = null;
    if (studentId) {
      student = await Student.findByIdAndUpdate(
        studentId,
        {
          photo: `/uploads/photos/${filename}`,
          photoStatus: processedImage.faceDetected ? 'processed' : 'uploaded',
        },
        { new: true }
      );
    }
    
    res.status(200).json({
      success: true,
      message: 'Photo uploaded successfully',
      data: {
        photoUrl: `/uploads/photos/${filename}`,
        filename,
        dimensions: {
          width: processedImage.width,
          height: processedImage.height,
        },
        size: processedImage.size,
        faceDetected: processedImage.faceDetected,
        student: student ? student.toFormattedJSON() : null,
      },
    });
  } catch (error) {
    console.error('Upload photo error:', error);
    // Clean up temp file on error
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).json({
      success: false,
      message: 'Failed to upload photo',
      error: error.message,
    });
  }
};

/**
 * Upload multiple photos (bulk)
 * POST /api/photos/upload-bulk
 */
const uploadBulkPhotos = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No photos uploaded',
      });
    }
    
    const { autoMatch = 'true', namingPattern = 'name' } = req.body;
    
    const results = {
      success: [],
      errors: [],
      matched: [],
      unmatched: [],
    };
    
    for (const file of req.files) {
      try {
        const filePath = file.path;
        const originalName = path.parse(file.originalname).name;
        
        // Process photo
        let processedImage;
        try {
          processedImage = await processPhoto(filePath, {
            targetWidth: 300,
            targetHeight: 400,
            quality: 90,
            autoCrop: true,
            detectFace: true,
          });
        } catch (processError) {
          const buffer = fs.readFileSync(filePath);
          processedImage = {
            buffer,
            width: 300,
            height: 400,
            format: 'jpeg',
            size: buffer.length,
            faceDetected: false,
          };
        }
        
        // Generate filename
        const filename = `${uuidv4()}.jpg`;
        const outputPath = path.join(UPLOAD_DIR, filename);
        
        // Save processed image
        fs.writeFileSync(outputPath, processedImage.buffer);
        
        // Clean up temp file
        fs.unlinkSync(filePath);
        
        const photoUrl = `/uploads/photos/${filename}`;
        
        // Auto-match to student if enabled
        let matchedStudent = null;
        if (autoMatch === 'true') {
          matchedStudent = await matchPhotoToStudent(originalName, namingPattern);
          
          if (matchedStudent) {
            matchedStudent.photo = photoUrl;
            matchedStudent.photoStatus = processedImage.faceDetected ? 'processed' : 'uploaded';
            await matchedStudent.save();
            
            results.matched.push({
              filename: file.originalname,
              student: matchedStudent.toFormattedJSON(),
            });
          } else {
            results.unmatched.push({
              filename: file.originalname,
              photoUrl,
            });
          }
        }
        
        results.success.push({
          filename: file.originalname,
          photoUrl,
          faceDetected: processedImage.faceDetected,
          matched: !!matchedStudent,
        });
      } catch (fileError) {
        results.errors.push({
          filename: file.originalname,
          error: fileError.message,
        });
        // Clean up temp file on error
        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }
      }
    }
    
    res.status(200).json({
      success: true,
      message: `Processed ${req.files.length} photos`,
      data: results,
    });
  } catch (error) {
    console.error('Bulk upload error:', error);
    // Clean up temp files on error
    if (req.files) {
      req.files.forEach(file => {
        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Failed to upload photos',
      error: error.message,
    });
  }
};

/**
 * Capture photo from camera
 * POST /api/photos/capture
 */
const capturePhoto = async (req, res) => {
  try {
    const { imageData, studentId } = req.body;
    
    if (!imageData) {
      return res.status(400).json({
        success: false,
        message: 'No image data provided',
      });
    }
    
    // Decode base64 image
    const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    
    // Process photo with face detection
    let processedImage;
    try {
      processedImage = await processPhoto(buffer, {
        targetWidth: 300,
        targetHeight: 400,
        quality: 90,
        autoCrop: true,
        detectFace: true,
      });
    } catch (processError) {
      console.warn('Photo processing failed:', processError.message);
      processedImage = {
        buffer,
        width: 300,
        height: 400,
        format: 'jpeg',
        size: buffer.length,
        faceDetected: false,
      };
    }
    
    // Generate filename
    const filename = `${uuidv4()}.jpg`;
    const outputPath = path.join(UPLOAD_DIR, filename);
    
    // Save image
    fs.writeFileSync(outputPath, processedImage.buffer);
    
    // Update student if studentId provided
    let student = null;
    if (studentId) {
      student = await Student.findByIdAndUpdate(
        studentId,
        {
          photo: `/uploads/photos/${filename}`,
          photoStatus: 'captured',
        },
        { new: true }
      );
    }
    
    res.status(200).json({
      success: true,
      message: 'Photo captured successfully',
      data: {
        photoUrl: `/uploads/photos/${filename}`,
        filename,
        dimensions: {
          width: processedImage.width,
          height: processedImage.height,
        },
        faceDetected: processedImage.faceDetected,
        student: student ? student.toFormattedJSON() : null,
      },
    });
  } catch (error) {
    console.error('Capture photo error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to capture photo',
      error: error.message,
    });
  }
};

/**
 * Detect face in image
 * POST /api/photos/detect-face
 */
const detectFaceInImage = async (req, res) => {
  try {
    const { imageData } = req.body;
    
    if (!imageData && !req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image provided',
      });
    }
    
    let buffer;
    
    if (imageData) {
      // Decode base64
      const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
      buffer = Buffer.from(base64Data, 'base64');
    } else {
      buffer = fs.readFileSync(req.file.path);
    }
    
    // Check for face
    const faceDetected = await hasFace(buffer);
    
    // Clean up temp file if exists
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(200).json({
      success: true,
      data: {
        faceDetected,
        message: faceDetected ? 'Face detected' : 'No face detected',
      },
    });
  } catch (error) {
    console.error('Face detection error:', error);
    // Clean up temp file on error
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).json({
      success: false,
      message: 'Failed to detect face',
      error: error.message,
    });
  }
};

/**
 * Match photo to student based on filename
 * @param {String} filename - Photo filename
 * @param {String} pattern - Matching pattern (name, roll, id)
 * @returns {Promise<Object|null>} Matched student or null
 */
const matchPhotoToStudent = async (filename, pattern) => {
  try {
    let query = {};
    
    // Clean filename (remove extensions, underscores, etc.)
    const cleanName = filename.replace(/[_-]/g, ' ').trim();
    
    switch (pattern) {
      case 'name':
        // Try to match by full name
        const nameParts = cleanName.split(' ');
        if (nameParts.length >= 2) {
          query = {
            $or: [
              { firstName: new RegExp(nameParts[0], 'i') },
              { lastName: new RegExp(nameParts[nameParts.length - 1], 'i') },
              { fullName: new RegExp(cleanName, 'i') },
            ],
          };
        } else {
          query = {
            $or: [
              { firstName: new RegExp(cleanName, 'i') },
              { lastName: new RegExp(cleanName, 'i') },
            ],
          };
        }
        break;
        
      case 'roll':
        // Match by roll number
        query = { rollNumber: new RegExp(`^${filename}$`, 'i') };
        break;
        
      case 'id':
        // Match by student ID
        query = { studentId: new RegExp(`^${filename}$`, 'i') };
        break;
        
      default:
        // Try all patterns
        query = {
          $or: [
            { fullName: new RegExp(cleanName, 'i') },
            { rollNumber: new RegExp(`^${filename}$`, 'i') },
            { studentId: new RegExp(`^${filename}$`, 'i') },
          ],
        };
    }
    
    query.isActive = true;
    
    const student = await Student.findOne(query);
    return student;
  } catch (error) {
    console.error('Match photo error:', error);
    return null;
  }
};

/**
 * Auto-match photos to students
 * POST /api/photos/auto-match
 */
const autoMatchPhotos = async (req, res) => {
  try {
    const { namingPattern = 'name' } = req.body;
    
    // Get all unassigned photos
    const photosDir = UPLOAD_DIR;
    const files = fs.readdirSync(photosDir);
    
    const results = {
      matched: [],
      unmatched: [],
      errors: [],
    };
    
    for (const filename of files) {
      if (!filename.endsWith('.jpg') && !filename.endsWith('.png')) continue;
      
      try {
        const nameWithoutExt = path.parse(filename).name;
        const matchedStudent = await matchPhotoToStudent(nameWithoutExt, namingPattern);
        
        if (matchedStudent) {
          // Update student with photo
          matchedStudent.photo = `/uploads/photos/${filename}`;
          matchedStudent.photoStatus = 'uploaded';
          await matchedStudent.save();
          
          results.matched.push({
            filename,
            student: matchedStudent.toFormattedJSON(),
          });
        } else {
          results.unmatched.push(filename);
        }
      } catch (error) {
        results.errors.push({
          filename,
          error: error.message,
        });
      }
    }
    
    res.status(200).json({
      success: true,
      message: `Matched ${results.matched.length} photos, ${results.unmatched.length} unmatched`,
      data: results,
    });
  } catch (error) {
    console.error('Auto-match error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to auto-match photos',
      error: error.message,
    });
  }
};

/**
 * Delete photo
 * DELETE /api/photos/:filename
 */
const deletePhoto = async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Security: prevent directory traversal
    const safeFilename = path.basename(filename);
    const filePath = path.join(UPLOAD_DIR, safeFilename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        message: 'Photo not found',
      });
    }
    
    // Delete file
    fs.unlinkSync(filePath);
    
    // Update any students using this photo
    await Student.updateMany(
      { photo: `/uploads/photos/${safeFilename}` },
      { photo: null, photoStatus: 'pending' }
    );
    
    res.status(200).json({
      success: true,
      message: 'Photo deleted successfully',
    });
  } catch (error) {
    console.error('Delete photo error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete photo',
      error: error.message,
    });
  }
};

module.exports = {
  uploadPhoto,
  uploadBulkPhotos,
  capturePhoto,
  detectFaceInImage,
  autoMatchPhotos,
  deletePhoto,
};
