/**
 * Student Controller
 * Handle student-related operations
 */

const { Student } = require('../models');
const { parseExcelFile, exportToExcel, generateTemplate } = require('../utils/excelParser');
const { cleanupTempFiles } = require('../middleware/upload');
const path = require('path');
const fs = require('fs');

/**
 * Get all students with pagination and filters
 * GET /api/students
 */
const getAllStudents = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = '',
      class: classFilter = '',
      section = '',
      academicYear = '',
      photoStatus = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = req.query;
    
    // Build query
    const query = { isActive: true };
    
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { fullName: { $regex: search, $options: 'i' } },
        { studentId: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    
    if (classFilter) query.class = classFilter;
    if (section) query.section = section.toUpperCase();
    if (academicYear) query.academicYear = academicYear;
    if (photoStatus) query.photoStatus = photoStatus;
    
    // Build sort
    const sort = {};
    sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
    
    // Execute query
    const students = await Student.find(query)
      .sort(sort)
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    
    const total = await Student.countDocuments(query);
    
    // Get unique classes and sections for filters
    const classes = await Student.distinct('class', { isActive: true });
    const sections = await Student.distinct('section', { isActive: true });
    const academicYears = await Student.distinct('academicYear', { isActive: true });
    
    res.status(200).json({
      success: true,
      data: {
        students: students.map(s => s.toFormattedJSON()),
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
        filters: {
          classes: classes.sort(),
          sections: sections.sort(),
          academicYears: academicYears.sort(),
        },
      },
    });
  } catch (error) {
    console.error('Get students error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get students',
      error: error.message,
    });
  }
};

/**
 * Get student by ID
 * GET /api/students/:id
 */
const getStudentById = async (req, res) => {
  try {
    const { id } = req.params;
    
    const student = await Student.findById(id);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    res.status(200).json({
      success: true,
      data: {
        student: student.toFormattedJSON(),
      },
    });
  } catch (error) {
    console.error('Get student error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get student',
      error: error.message,
    });
  }
};

/**
 * Create new student
 * POST /api/students
 */
const createStudent = async (req, res) => {
  try {
    const studentData = req.body;
    
    // Generate student ID if not provided
    if (!studentData.studentId) {
      studentData.studentId = await Student.generateStudentId(
        studentData.class,
        studentData.section
      );
    }
    
    // Set created by
    studentData.createdBy = req.user.id;
    
    const student = await Student.create(studentData);
    
    res.status(201).json({
      success: true,
      message: 'Student created successfully',
      data: {
        student: student.toFormattedJSON(),
      },
    });
  } catch (error) {
    console.error('Create student error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create student',
      error: error.message,
    });
  }
};

/**
 * Update student
 * PUT /api/students/:id
 */
const updateStudent = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    const student = await Student.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Student updated successfully',
      data: {
        student: student.toFormattedJSON(),
      },
    });
  } catch (error) {
    console.error('Update student error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update student',
      error: error.message,
    });
  }
};

/**
 * Delete student (soft delete)
 * DELETE /api/students/:id
 */
const deleteStudent = async (req, res) => {
  try {
    const { id } = req.params;
    
    const student = await Student.findByIdAndUpdate(
      id,
      { isActive: false },
      { new: true }
    );
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Student deleted successfully',
    });
  } catch (error) {
    console.error('Delete student error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete student',
      error: error.message,
    });
  }
};

/**
 * Bulk create students from Excel
 * POST /api/students/bulk
 */
const bulkCreateStudents = async (req, res) => {
  try {
    const { students } = req.body;
    
    const results = {
      success: [],
      errors: [],
    };
    
    for (const studentData of students) {
      try {
        // Generate student ID if not provided
        if (!studentData.studentId) {
          studentData.studentId = await Student.generateStudentId(
            studentData.class,
            studentData.section
          );
        }
        
        studentData.createdBy = req.user.id;
        
        const student = await Student.create(studentData);
        results.success.push(student.toFormattedJSON());
      } catch (error) {
        results.errors.push({
          data: studentData,
          error: error.message,
        });
      }
    }
    
    res.status(200).json({
      success: true,
      message: `Created ${results.success.length} students, ${results.errors.length} errors`,
      data: results,
    });
  } catch (error) {
    console.error('Bulk create error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to bulk create students',
      error: error.message,
    });
  }
};

/**
 * Upload Excel file and parse students
 * POST /api/students/upload-excel
 */
const uploadExcel = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded',
      });
    }
    
    const filePath = req.file.path;
    
    // Parse Excel file
    const result = await parseExcelFile(filePath);
    
    // Clean up temp file
    cleanupTempFiles(req.file);
    
    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message,
        error: result.error,
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Excel file parsed successfully',
      data: {
        totalRows: result.totalRows,
        validStudents: result.validStudents,
        errorCount: result.errorCount,
        students: result.students,
        errors: result.errors,
      },
    });
  } catch (error) {
    console.error('Upload Excel error:', error);
    // Clean up temp file on error
    if (req.file) cleanupTempFiles(req.file);
    
    res.status(500).json({
      success: false,
      message: 'Failed to process Excel file',
      error: error.message,
    });
  }
};

/**
 * Download Excel template
 * GET /api/students/template
 */
const downloadTemplate = async (req, res) => {
  try {
    const templatePath = await generateTemplate();
    
    res.download(templatePath, 'student_template.xlsx', (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(500).json({
          success: false,
          message: 'Failed to download template',
        });
      }
      // Clean up temp file after download
      fs.unlink(templatePath, () => {});
    });
  } catch (error) {
    console.error('Template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate template',
      error: error.message,
    });
  }
};

/**
 * Export students to Excel
 * GET /api/students/export
 */
const exportStudents = async (req, res) => {
  try {
    const { class: classFilter, section, academicYear } = req.query;
    
    // Build query
    const query = { isActive: true };
    if (classFilter) query.class = classFilter;
    if (section) query.section = section.toUpperCase();
    if (academicYear) query.academicYear = academicYear;
    
    const students = await Student.find(query).sort({ createdAt: -1 });
    
    const filename = `students_export_${Date.now()}.xlsx`;
    const outputPath = path.join(__dirname, '..', 'uploads', 'temp', filename);
    
    await exportToExcel(students, outputPath);
    
    res.download(outputPath, filename, (err) => {
      if (err) {
        console.error('Export download error:', err);
      }
      // Clean up file after download
      fs.unlink(outputPath, () => {});
    });
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export students',
      error: error.message,
    });
  }
};

/**
 * Get students without photos
 * GET /api/students/without-photos
 */
const getStudentsWithoutPhotos = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const query = {
      isActive: true,
      $or: [
        { photo: null },
        { photo: '' },
        { photoStatus: 'pending' },
      ],
    };
    
    const students = await Student.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    
    const total = await Student.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        students: students.map(s => s.toFormattedJSON()),
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Get students without photos error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get students',
      error: error.message,
    });
  }
};

/**
 * Update student photo
 * PUT /api/students/:id/photo
 */
const updatePhoto = async (req, res) => {
  try {
    const { id } = req.params;
    const { photoUrl } = req.body;
    
    const student = await Student.findByIdAndUpdate(
      id,
      {
        photo: photoUrl,
        photoStatus: 'uploaded',
      },
      { new: true }
    );
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found',
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Photo updated successfully',
      data: {
        student: student.toFormattedJSON(),
      },
    });
  } catch (error) {
    console.error('Update photo error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update photo',
      error: error.message,
    });
  }
};

module.exports = {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent,
  bulkCreateStudents,
  uploadExcel,
  downloadTemplate,
  exportStudents,
  getStudentsWithoutPhotos,
  updatePhoto,
};
