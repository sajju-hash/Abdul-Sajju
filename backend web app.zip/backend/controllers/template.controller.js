/**
 * Template Controller
 * Handle ID card template operations
 */

const { Template } = require('../models');

/**
 * Get all templates
 * GET /api/templates
 */
const getAllTemplates = async (req, res) => {
  try {
    const { page = 1, limit = 10, category = '', search = '' } = req.query;
    
    const query = { isActive: true };
    
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }
    
    const templates = await Template.find(query)
      .populate('createdBy', 'name email')
      .sort({ isDefault: -1, createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    
    const total = await Template.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        templates,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Get templates error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get templates',
      error: error.message,
    });
  }
};

/**
 * Get template by ID
 * GET /api/templates/:id
 */
const getTemplateById = async (req, res) => {
  try {
    const { id } = req.params;
    
    const template = await Template.findById(id)
      .populate('createdBy', 'name email');
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'Template not found',
      });
    }
    
    res.status(200).json({
      success: true,
      data: { template },
    });
  } catch (error) {
    console.error('Get template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get template',
      error: error.message,
    });
  }
};

/**
 * Get default template
 * GET /api/templates/default
 */
const getDefaultTemplate = async (req, res) => {
  try {
    const { category = 'student' } = req.query;
    
    const template = await Template.findOne({
      category,
      isDefault: true,
      isActive: true,
    });
    
    if (!template) {
      // Return any active template if no default
      const anyTemplate = await Template.findOne({ isActive: true });
      
      if (!anyTemplate) {
        return res.status(404).json({
          success: false,
          message: 'No templates found',
        });
      }
      
      return res.status(200).json({
        success: true,
        data: { template: anyTemplate },
      });
    }
    
    res.status(200).json({
      success: true,
      data: { template },
    });
  } catch (error) {
    console.error('Get default template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get default template',
      error: error.message,
    });
  }
};

/**
 * Create new template
 * POST /api/templates
 */
const createTemplate = async (req, res) => {
  try {
    const templateData = req.body;
    templateData.createdBy = req.user.id;
    
    // If this is set as default, unset other defaults in same category
    if (templateData.isDefault) {
      await Template.updateMany(
        { category: templateData.category || 'student' },
        { isDefault: false }
      );
    }
    
    const template = await Template.create(templateData);
    
    res.status(201).json({
      success: true,
      message: 'Template created successfully',
      data: { template },
    });
  } catch (error) {
    console.error('Create template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create template',
      error: error.message,
    });
  }
};

/**
 * Update template
 * PUT /api/templates/:id
 */
const updateTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    // If setting as default, unset others
    if (updateData.isDefault) {
      const current = await Template.findById(id);
      if (current) {
        await Template.updateMany(
          { category: updateData.category || current.category, _id: { $ne: id } },
          { isDefault: false }
        );
      }
    }
    
    const template = await Template.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'Template not found',
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Template updated successfully',
      data: { template },
    });
  } catch (error) {
    console.error('Update template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update template',
      error: error.message,
    });
  }
};

/**
 * Delete template (soft delete)
 * DELETE /api/templates/:id
 */
const deleteTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    
    const template = await Template.findByIdAndUpdate(
      id,
      { isActive: false },
      { new: true }
    );
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'Template not found',
      });
    }
    
    res.status(200).json({
      success: true,
      message: 'Template deleted successfully',
    });
  } catch (error) {
    console.error('Delete template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete template',
      error: error.message,
    });
  }
};

/**
 * Duplicate template
 * POST /api/templates/:id/duplicate
 */
const duplicateTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    const template = await Template.findById(id);
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'Template not found',
      });
    }
    
    const newTemplate = await template.duplicate(name, req.user.id);
    
    res.status(201).json({
      success: true,
      message: 'Template duplicated successfully',
      data: { template: newTemplate },
    });
  } catch (error) {
    console.error('Duplicate template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to duplicate template',
      error: error.message,
    });
  }
};

/**
 * Set template as default
 * PUT /api/templates/:id/set-default
 */
const setDefaultTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    
    const template = await Template.findById(id);
    
    if (!template) {
      return res.status(404).json({
        success: false,
        message: 'Template not found',
      });
    }
    
    // Unset other defaults in same category
    await Template.updateMany(
      { category: template.category, _id: { $ne: id } },
      { isDefault: false }
    );
    
    // Set this as default
    template.isDefault = true;
    await template.save();
    
    res.status(200).json({
      success: true,
      message: 'Template set as default',
      data: { template },
    });
  } catch (error) {
    console.error('Set default template error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to set default template',
      error: error.message,
    });
  }
};

/**
 * Get template categories
 * GET /api/templates/categories
 */
const getCategories = async (req, res) => {
  try {
    const categories = await Template.distinct('category', { isActive: true });
    
    res.status(200).json({
      success: true,
      data: { categories },
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get categories',
      error: error.message,
    });
  }
};

module.exports = {
  getAllTemplates,
  getTemplateById,
  getDefaultTemplate,
  createTemplate,
  updateTemplate,
  deleteTemplate,
  duplicateTemplate,
  setDefaultTemplate,
  getCategories,
};
