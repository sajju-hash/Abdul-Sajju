/**
 * Password Reset Script
 * Run: node reset-password.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { User } = require('./models');

const args = process.argv.slice(2);
const email = args[0] || 'admin@school.com';
const newPassword = args[1] || 'admin123';

async function resetPassword() {
  try {
    // Connect to MongoDB
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/school_id_cards';
    await mongoose.connect(mongoURI);
    console.log('Connected to MongoDB');

    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      console.log(`User not found: ${email}`);
      console.log('\nAvailable users:');
      const users = await User.find({}, 'email name role');
      users.forEach(u => console.log(`  - ${u.email} (${u.name}) [${u.role}]`));
      process.exit(1);
    }

    // Reset password
    user.password = newPassword;
    await user.save();

    console.log('\n✅ Password reset successful!');
    console.log(`   Email:    ${email}`);
    console.log(`   Password: ${newPassword}`);
    console.log(`   Role:     ${user.role}`);
    console.log('\nYou can now login with these credentials.');

  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await mongoose.disconnect();
  }
}

console.log('========================================');
console.log('  School ID Card - Password Reset');
console.log('========================================');
console.log(`   User:  ${email}`);
console.log(`   New Password: ${newPassword}`);
console.log('========================================\n');

resetPassword();
