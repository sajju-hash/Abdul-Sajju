/**
 * Settings Model
 * Schema for application-wide settings
 */

const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  // School/Organization Information
  schoolInfo: {
    name: {
      type: String,
      default: 'My School',
    },
    address: {
      type: String,
      default: '',
    },
    phone: {
      type: String,
      default: '',
    },
    email: {
      type: String,
      default: '',
    },
    website: {
      type: String,
      default: '',
    },
    logo: {
      type: String,
      default: null,
    },
    tagline: {
      type: String,
      default: '',
    },
  },
  
  // ID Card Settings
  idCardSettings: {
    defaultTemplate: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Template',
      default: null,
    },
    cardWidth: {
      type: Number,
      default: 600, // pixels
    },
    cardHeight: {
      type: Number,
      default: 378, // pixels
    },
    dpi: {
      type: Number,
      default: 300,
    },
    format: {
      type: String,
      enum: ['png', 'jpg', 'pdf'],
      default: 'png',
    },
    printLayout: {
      cardsPerRow: { type: Number, default: 2 },
      cardsPerColumn: { type: Number, default: 5 },
      margin: { type: Number, default: 10 },
      spacing: { type: Number, default: 5 },
    },
  },
  
  // Photo Settings
  photoSettings: {
    maxFileSize: {
      type: Number,
      default: 5, // MB
    },
    allowedFormats: [{
      type: String,
      default: ['jpg', 'jpeg', 'png'],
    }],
    defaultWidth: {
      type: Number,
      default: 300,
    },
    defaultHeight: {
      type: Number,
      default: 400,
    },
    autoCrop: {
      type: Boolean,
      default: true,
    },
    faceDetection: {
      type: Boolean,
      default: true,
    },
    compressionQuality: {
      type: Number,
      default: 0.8,
    },
  },
  
  // QR Code Settings
  qrCodeSettings: {
    enabled: {
      type: Boolean,
      default: true,
    },
    size: {
      type: Number,
      default: 100,
    },
    errorCorrectionLevel: {
      type: String,
      enum: ['L', 'M', 'Q', 'H'],
      default: 'M',
    },
    encodeData: {
      type: String,
      default: 'studentId', // studentId, profileUrl, custom
    },
    customUrl: {
      type: String,
      default: '',
    },
  },
  
  // Barcode Settings
  barcodeSettings: {
    enabled: {
      type: Boolean,
      default: true,
    },
    format: {
      type: String,
      enum: ['CODE128', 'CODE39', 'EAN13', 'UPC'],
      default: 'CODE128',
    },
    width: {
      type: Number,
      default: 2,
    },
    height: {
      type: Number,
      default: 50,
    },
    displayValue: {
      type: Boolean,
      default: true,
    },
  },
  
  // Excel Import Settings
  excelSettings: {
    requiredFields: [{
      type: String,
      default: ['firstName', 'lastName', 'class', 'section', 'rollNumber'],
    }],
    optionalFields: [{
      type: String,
      default: ['email', 'phone', 'address', 'bloodGroup', 'dateOfBirth'],
    }],
    sheetName: {
      type: String,
      default: 'Students',
    },
    headerRow: {
      type: Number,
      default: 1,
    },
    autoGenerateId: {
      type: Boolean,
      default: true,
    },
  },
  
  // Security Settings
  securitySettings: {
    maxLoginAttempts: {
      type: Number,
      default: 5,
    },
    lockoutDuration: {
      type: Number,
      default: 30, // minutes
    },
    passwordMinLength: {
      type: Number,
      default: 6,
    },
    sessionTimeout: {
      type: Number,
      default: 60, // minutes
    },
    requireStrongPassword: {
      type: Boolean,
      default: false,
    },
  },
  
  // Updated by
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Ensure only one settings document exists
settingsSchema.statics.getSettings = async function() {
  let settings = await this.findOne();
  if (!settings) {
    settings = await this.create({});
  }
  return settings;
};

settingsSchema.statics.updateSettings = async function(data, userId) {
  let settings = await this.findOne();
  if (!settings) {
    settings = new this();
  }
  
  // Merge nested objects
  if (data.schoolInfo) {
    Object.assign(settings.schoolInfo, data.schoolInfo);
  }
  if (data.idCardSettings) {
    Object.assign(settings.idCardSettings, data.idCardSettings);
  }
  if (data.photoSettings) {
    Object.assign(settings.photoSettings, data.photoSettings);
  }
  if (data.qrCodeSettings) {
    Object.assign(settings.qrCodeSettings, data.qrCodeSettings);
  }
  if (data.barcodeSettings) {
    Object.assign(settings.barcodeSettings, data.barcodeSettings);
  }
  if (data.excelSettings) {
    Object.assign(settings.excelSettings, data.excelSettings);
  }
  if (data.securitySettings) {
    Object.assign(settings.securitySettings, data.securitySettings);
  }
  
  settings.updatedBy = userId;
  settings.updatedAt = new Date();
  
  return await settings.save();
};

module.exports = mongoose.model('Settings', settingsSchema);
