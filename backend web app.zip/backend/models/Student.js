/**
 * Student Model
 * Schema for storing student information
 */

const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  // Unique identifier for the student
  studentId: {
    type: String,
    required: [true, 'Student ID is required'],
    unique: true,
    trim: true,
    uppercase: true,
  },
  
  // Personal Information
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true,
    maxlength: [50, 'First name cannot exceed 50 characters'],
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true,
    maxlength: [50, 'Last name cannot exceed 50 characters'],
  },
  fullName: {
    type: String,
    trim: true,
  },
  
  // Academic Information
  class: {
    type: String,
    required: [true, 'Class is required'],
    trim: true,
    maxlength: [20, 'Class cannot exceed 20 characters'],
  },
  section: {
    type: String,
    required: [true, 'Section is required'],
    trim: true,
    uppercase: true,
    maxlength: [10, 'Section cannot exceed 10 characters'],
  },
  rollNumber: {
    type: String,
    required: [true, 'Roll number is required'],
    trim: true,
    maxlength: [20, 'Roll number cannot exceed 20 characters'],
  },
  academicYear: {
    type: String,
    trim: true,
    default: () => new Date().getFullYear().toString(),
  },
  
  // Contact Information
  email: {
    type: String,
    trim: true,
    lowercase: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please enter a valid email',
    ],
    default: null,
  },
  phone: {
    type: String,
    trim: true,
    maxlength: [20, 'Phone number cannot exceed 20 characters'],
    default: null,
  },
  address: {
    type: String,
    trim: true,
    maxlength: [200, 'Address cannot exceed 200 characters'],
    default: null,
  },
  
  // Photo Information
  photo: {
    type: String, // URL/path to photo
    default: null,
  },
  photoStatus: {
    type: String,
    enum: ['pending', 'uploaded', 'captured', 'processed'],
    default: 'pending',
  },
  
  // ID Card Information
  idCardGenerated: {
    type: Boolean,
    default: false,
  },
  idCardUrl: {
    type: String,
    default: null,
  },
  qrCode: {
    type: String, // URL/path to QR code image
    default: null,
  },
  barcode: {
    type: String, // URL/path to barcode image
    default: null,
  },
  
  // Additional Fields (flexible)
  bloodGroup: {
    type: String,
    trim: true,
    uppercase: true,
    maxlength: [5, 'Blood group cannot exceed 5 characters'],
    default: null,
  },
  dateOfBirth: {
    type: Date,
    default: null,
  },
  gender: {
    type: String,
    enum: ['male', 'female', 'other', null],
    default: null,
  },
  emergencyContact: {
    name: { type: String, trim: true, default: null },
    phone: { type: String, trim: true, default: null },
    relation: { type: String, trim: true, default: null },
  },
  
  // Custom fields for additional flexibility
  customFields: {
    type: Map,
    of: String,
    default: {},
  },
  
  // Metadata
  isActive: {
    type: Boolean,
    default: true,
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Indexes for faster queries
studentSchema.index({ studentId: 1 });
studentSchema.index({ class: 1, section: 1 });
studentSchema.index({ rollNumber: 1 });
studentSchema.index({ fullName: 'text', firstName: 'text', lastName: 'text' });
studentSchema.index({ createdAt: -1 });
studentSchema.index({ isActive: 1 });

// Pre-save middleware to generate full name
studentSchema.pre('save', function(next) {
  this.fullName = `${this.firstName} ${this.lastName}`.trim();
  next();
});

// Update timestamp on update
studentSchema.pre('findOneAndUpdate', function(next) {
  this.set({ updatedAt: new Date() });
  next();
});

// Virtual for age calculation
studentSchema.virtual('age').get(function() {
  if (!this.dateOfBirth) return null;
  const today = new Date();
  const birthDate = new Date(this.dateOfBirth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
});

// Method to get formatted student info
studentSchema.methods.toFormattedJSON = function() {
  return {
    id: this._id,
    studentId: this.studentId,
    fullName: this.fullName,
    firstName: this.firstName,
    lastName: this.lastName,
    class: this.class,
    section: this.section,
    rollNumber: this.rollNumber,
    academicYear: this.academicYear,
    email: this.email,
    phone: this.phone,
    address: this.address,
    photo: this.photo,
    photoStatus: this.photoStatus,
    idCardGenerated: this.idCardGenerated,
    idCardUrl: this.idCardUrl,
    qrCode: this.qrCode,
    barcode: this.barcode,
    bloodGroup: this.bloodGroup,
    dateOfBirth: this.dateOfBirth,
    gender: this.gender,
    age: this.age,
    emergencyContact: this.emergencyContact,
    customFields: this.customFields,
    isActive: this.isActive,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

// Static method to generate unique student ID
studentSchema.statics.generateStudentId = async function(className, section) {
  const year = new Date().getFullYear().toString().slice(-2);
  const prefix = `${year}${className}${section}`.toUpperCase();
  
  // Find the last student with this prefix
  const lastStudent = await this.findOne(
    { studentId: new RegExp(`^${prefix}`) },
    { studentId: 1 },
    { sort: { studentId: -1 } }
  );
  
  let sequence = 1;
  if (lastStudent) {
    const lastSequence = parseInt(lastStudent.studentId.slice(-4));
    if (!isNaN(lastSequence)) {
      sequence = lastSequence + 1;
    }
  }
  
  return `${prefix}${sequence.toString().padStart(4, '0')}`;
};

module.exports = mongoose.model('Student', studentSchema);
