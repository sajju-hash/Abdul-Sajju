/**
 * Models Index
 * Export all models from a single file
 */

const User = require('./User');
const Student = require('./Student');
const Template = require('./Template');
const Settings = require('./Settings');
const School = require('./School');

module.exports = {
  User,
  Student,
  Template,
  Settings,
  School,
};
