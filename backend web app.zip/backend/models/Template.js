/**
 * Template Model
 * Schema for ID card templates with drag-drop configuration
 */

const mongoose = require('mongoose');

// Schema for individual template elements
const templateElementSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ['text', 'image', 'qrCode', 'barcode', 'rectangle', 'line'],
    required: true,
  },
  label: {
    type: String,
    required: true,
  },
  field: {
    type: String, // Maps to student field (e.g., 'firstName', 'photo', 'studentId')
    default: null,
  },
  x: {
    type: Number,
    required: true,
    default: 0,
  },
  y: {
    type: Number,
    required: true,
    default: 0,
  },
  width: {
    type: Number,
    required: true,
    default: 100,
  },
  height: {
    type: Number,
    required: true,
    default: 30,
  },
  // Styling properties
  style: {
    fontSize: { type: Number, default: 14 },
    fontFamily: { type: String, default: 'Arial' },
    fontWeight: { type: String, default: 'normal' },
    fontStyle: { type: String, default: 'normal' },
    textAlign: { type: String, default: 'left' },
    color: { type: String, default: '#000000' },
    backgroundColor: { type: String, default: 'transparent' },
    borderWidth: { type: Number, default: 0 },
    borderColor: { type: String, default: '#000000' },
    borderRadius: { type: Number, default: 0 },
    opacity: { type: Number, default: 1 },
    rotation: { type: Number, default: 0 },
    zIndex: { type: Number, default: 1 },
  },
  // For static text content
  content: {
    type: String,
    default: '',
  },
  // For image elements
  imageUrl: {
    type: String,
    default: null,
  },
  // Whether element is editable in builder
  isEditable: {
    type: Boolean,
    default: true,
  },
  // Whether element is locked (can't be moved/deleted)
  isLocked: {
    type: Boolean,
    default: false,
  },
});

// Main template schema
const templateSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Template name is required'],
    trim: true,
    maxlength: [100, 'Template name cannot exceed 100 characters'],
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot exceed 500 characters'],
    default: '',
  },
  
  // Template dimensions (in pixels, standard ID card size)
  dimensions: {
    width: { type: Number, default: 600 },  // ~85mm at 180 DPI
    height: { type: Number, default: 378 }, // ~54mm at 180 DPI
    unit: { type: String, default: 'px' },
  },
  
  // Card orientation
  orientation: {
    type: String,
    enum: ['portrait', 'landscape'],
    default: 'landscape',
  },
  
  // Template elements (drag-drop components)
  elements: [templateElementSchema],
  
  // Background settings
  background: {
    color: { type: String, default: '#ffffff' },
    image: { type: String, default: null },
    gradient: {
      enabled: { type: Boolean, default: false },
      type: { type: String, default: 'linear' },
      colors: [{ type: String }],
      angle: { type: Number, default: 90 },
    },
  },
  
  // School/Organization branding
  branding: {
    schoolName: { type: String, default: '' },
    logo: { type: String, default: null },
    tagline: { type: String, default: '' },
    website: { type: String, default: '' },
    contactInfo: { type: String, default: '' },
  },
  
  // Template category
  category: {
    type: String,
    enum: ['student', 'staff', 'visitor', 'custom'],
    default: 'student',
  },
  
  // Default template flag
  isDefault: {
    type: Boolean,
    default: false,
  },
  
  // Template status
  isActive: {
    type: Boolean,
    default: true,
  },
  
  // Usage statistics
  usageCount: {
    type: Number,
    default: 0,
  },
  
  // Created by
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  
  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Indexes
templateSchema.index({ name: 'text', description: 'text' });
templateSchema.index({ category: 1 });
templateSchema.index({ isDefault: 1 });
templateSchema.index({ isActive: 1 });
templateSchema.index({ createdBy: 1 });

// Pre-save middleware
templateSchema.pre('save', function(next) {
  // Ensure only one default template per category
  if (this.isDefault && this.isModified('isDefault')) {
    // This will be handled by a post-save hook or middleware
  }
  next();
});

// Update timestamp on update
templateSchema.pre('findOneAndUpdate', function(next) {
  this.set({ updatedAt: new Date() });
  next();
});

// Method to duplicate template
templateSchema.methods.duplicate = async function(newName, userId) {
  const duplicateData = this.toObject();
  delete duplicateData._id;
  delete duplicateData.createdAt;
  delete duplicateData.updatedAt;
  delete duplicateData.usageCount;
  
  duplicateData.name = newName || `${this.name} (Copy)`;
  duplicateData.isDefault = false;
  duplicateData.createdBy = userId;
  
  const Template = mongoose.model('Template');
  return await Template.create(duplicateData);
};

// Method to increment usage count
templateSchema.methods.incrementUsage = async function() {
  this.usageCount += 1;
  return await this.save();
};

// Static method to get default template
templateSchema.statics.getDefault = async function(category = 'student') {
  return await this.findOne({ category, isDefault: true, isActive: true });
};

module.exports = mongoose.model('Template', templateSchema);
