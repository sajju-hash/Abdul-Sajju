/**
 * School Model
 * Multi-tenant school schema
 */

const mongoose = require('mongoose');

const schoolSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'School name is required'],
    trim: true,
  },
  slug: {
    type: String,
    unique: true,
    lowercase: true,
  },
  logo: {
    type: String,
    default: null,
  },
  email: {
    type: String,
    required: true,
  },
  phone: String,
  address: String,
  city: String,
  state: String,
  country: String,
  pincode: String,
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  plan: {
    type: String,
    enum: ['free', 'starter', 'professional', 'enterprise'],
    default: 'free',
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'suspended', 'trial'],
    default: 'trial',
  },
  subscriptionExpiry: {
    type: Date,
    default: () => new Date(+new Date() + 30 * 24 * 60 * 60 * 1000),
  },
  maxStudents: {
    type: Number,
    default: 50,
  },
  maxTemplates: {
    type: Number,
    default: 2,
  },
  maxUsers: {
    type: Number,
    default: 2,
  },
  features: {
    qrCode: { type: Boolean, default: true },
    barcode: { type: Boolean, default: true },
    faceDetection: { type: Boolean, default: false },
    bulkImport: { type: Boolean, default: true },
    customDomain: { type: Boolean, default: false },
    apiAccess: { type: Boolean, default: false },
  },
  settings: {
    idCardPrefix: { type: String, default: 'ST' },
    academicYear: { type: String, default: '2024-25' },
    autoGenerateId: { type: Boolean, default: true },
  },
  stats: {
    totalStudents: { type: Number, default: 0 },
    totalTemplates: { type: Number, default: 0 },
    idCardsGenerated: { type: Number, default: 0 },
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

schoolSchema.pre('save', function(next) {
  if (!this.slug) {
    this.slug = this.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }
  next();
});

schoolSchema.methods.updateStats = async function() {
  const Student = mongoose.model('Student');
  const Template = mongoose.model('Template');
  this.stats.totalStudents = await Student.countDocuments({ schoolId: this._id });
  this.stats.totalTemplates = await Template.countDocuments({ schoolId: this._id });
  await this.save();
};

module.exports = mongoose.model('School', schoolSchema);
