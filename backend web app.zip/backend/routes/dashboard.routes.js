/**
 * Dashboard Routes
 * Dashboard statistics and overview routes
 */

const express = require('express');
const router = express.Router();
const { dashboardController } = require('../controllers');
const { authenticate } = require('../middleware/auth');

// Apply authentication to all routes
router.use(authenticate);

// Get dashboard statistics
router.get('/stats', dashboardController.getStats);

// Get recent students
router.get('/recent-students', dashboardController.getRecentStudents);

// Get students needing attention
router.get('/attention-needed', dashboardController.getAttentionNeeded);

// Get activity summary
router.get('/activity', dashboardController.getActivitySummary);

module.exports = router;
