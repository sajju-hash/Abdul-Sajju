/**
 * Auth Routes
 * Authentication and user management routes
 */

const express = require('express');
const router = express.Router();
const { authController } = require('../controllers');
const { authenticate, authorize } = require('../middleware/auth');
const {
  loginValidation,
  registerValidation,
} = require('../middleware/validation');

// Public routes
router.post('/login', loginValidation, authController.login);
router.post('/register', registerValidation, authController.register);

// Protected routes
router.use(authenticate);

router.get('/profile', authController.getProfile);
router.put('/profile', authController.updateProfile);
router.put('/change-password', authController.changePassword);
router.post('/logout', authController.logout);

// Admin only routes
router.get('/users', authorize('admin'), authController.getAllUsers);
router.put('/users/:id', authorize('admin'), authController.updateUser);
router.delete('/users/:id', authorize('admin'), authController.deleteUser);

module.exports = router;
