/**
 * ID Card Routes
 * ID card generation and export routes
 */

const express = require('express');
const router = express.Router();
const { idCardController } = require('../controllers');
const { authenticate } = require('../middleware/auth');
const { generateIdCardValidation } = require('../middleware/validation');

// Apply authentication to all routes
router.use(authenticate);

// Generate single ID card
router.post('/generate', generateIdCardValidation, idCardController.generateIdCard);

// Generate bulk ID cards
router.post('/generate-bulk', idCardController.generateBulkIdCards);

// Generate ID cards by class/section
router.post('/generate-by-class', idCardController.generateByClass);

// Get print layout HTML
router.post('/print-layout', idCardController.getPrintLayout);

// Preview ID card
router.post('/preview', idCardController.previewIdCard);

// Generate QR code
router.post('/qr-code', idCardController.generateStudentQRCode);

// Generate barcode
router.post('/barcode', idCardController.generateStudentBarcode);

// Download ID card file
router.get('/download/:filename', idCardController.downloadIdCard);

module.exports = router;
