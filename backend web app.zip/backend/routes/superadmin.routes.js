/**
 * Super Admin Routes
 * Super admin operations
 */

const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const superAdminController = require('../controllers/superadmin.controller');

// All routes require superadmin
router.use(authenticate);
router.use(authorize('superadmin'));

// Dashboard
router.get('/dashboard', superAdminController.getDashboardStats);

// Schools CRUD
router.get('/schools', superAdminController.getAllSchools);
router.post('/schools', superAdminController.createSchool);
router.get('/schools/:id', superAdminController.getSchoolById);
router.put('/schools/:id', superAdminController.updateSchool);
router.delete('/schools/:id', superAdminController.deleteSchool);

module.exports = router;
