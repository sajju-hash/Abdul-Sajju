/**
 * Template Routes
 * ID card template management routes
 */

const express = require('express');
const router = express.Router();
const { templateController } = require('../controllers');
const { authenticate, authorize } = require('../middleware/auth');
const {
  createTemplateValidation,
  templateIdValidation,
} = require('../middleware/validation');

// Apply authentication to all routes
router.use(authenticate);

// Get all templates
router.get('/', templateController.getAllTemplates);

// Get template categories
router.get('/categories', templateController.getCategories);

// Get default template
router.get('/default', templateController.getDefaultTemplate);

// Get template by ID
router.get('/:id', templateIdValidation, templateController.getTemplateById);

// Create new template (admin/editor)
router.post('/', authorize('admin', 'editor'), createTemplateValidation, templateController.createTemplate);

// Update template (admin/editor)
router.put('/:id', authorize('admin', 'editor'), templateIdValidation, templateController.updateTemplate);

// Delete template (admin only)
router.delete('/:id', authorize('admin'), templateIdValidation, templateController.deleteTemplate);

// Duplicate template
router.post('/:id/duplicate', authorize('admin', 'editor'), templateIdValidation, templateController.duplicateTemplate);

// Set as default template
router.put('/:id/set-default', authorize('admin'), templateIdValidation, templateController.setDefaultTemplate);

module.exports = router;
