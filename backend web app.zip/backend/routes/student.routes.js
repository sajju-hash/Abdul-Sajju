/**
 * Student Routes
 * Student management routes
 */

const express = require('express');
const router = express.Router();
const { studentController } = require('../controllers');
const { authenticate } = require('../middleware/auth');
const { upload, handleUploadError } = require('../middleware/upload');
const {
  createStudentValidation,
  updateStudentValidation,
  studentIdValidation,
  bulkStudentsValidation,
  paginationValidation,
  filterValidation,
} = require('../middleware/validation');

// Apply authentication to all routes
router.use(authenticate);

// Get all students with filters
router.get('/', paginationValidation, filterValidation, studentController.getAllStudents);

// Get students without photos
router.get('/without-photos', paginationValidation, studentController.getStudentsWithoutPhotos);

// Download Excel template
router.get('/template', studentController.downloadTemplate);

// Export students to Excel
router.get('/export', studentController.exportStudents);

// Get student by ID
router.get('/:id', studentIdValidation, studentController.getStudentById);

// Create new student
router.post('/', createStudentValidation, studentController.createStudent);

// Bulk create students
router.post('/bulk', bulkStudentsValidation, studentController.bulkCreateStudents);

// Upload Excel file
router.post(
  '/upload-excel',
  upload.single('excel'),
  handleUploadError,
  studentController.uploadExcel
);

// Update student
router.put('/:id', studentIdValidation, updateStudentValidation, studentController.updateStudent);

// Update student photo
router.put('/:id/photo', studentIdValidation, studentController.updatePhoto);

// Delete student
router.delete('/:id', studentIdValidation, studentController.deleteStudent);

module.exports = router;
