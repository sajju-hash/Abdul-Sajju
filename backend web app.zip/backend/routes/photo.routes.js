/**
 * Photo Routes
 * Photo upload and camera capture routes
 */

const express = require('express');
const router = express.Router();
const { photoController } = require('../controllers');
const { authenticate } = require('../middleware/auth');
const { upload, handleUploadError } = require('../middleware/upload');

// Apply authentication to all routes
router.use(authenticate);

// Upload single photo
router.post(
  '/upload',
  upload.single('photo'),
  handleUploadError,
  photoController.uploadPhoto
);

// Upload multiple photos (bulk)
router.post(
  '/upload-bulk',
  upload.array('photos', 50),
  handleUploadError,
  photoController.uploadBulkPhotos
);

// Capture photo from camera
router.post('/capture', photoController.capturePhoto);

// Detect face in image
router.post(
  '/detect-face',
  upload.single('image'),
  handleUploadError,
  photoController.detectFaceInImage
);

// Auto-match photos to students
router.post('/auto-match', photoController.autoMatchPhotos);

// Delete photo
router.delete('/:filename', photoController.deletePhoto);

module.exports = router;
