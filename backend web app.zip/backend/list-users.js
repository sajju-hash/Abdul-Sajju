/**
 * List All Users Script
 * Run: node list-users.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const { User } = require('./models');

async function listUsers() {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/school_id_cards';
    await mongoose.connect(mongoURI);

    const users = await User.find({}, 'name email role isActive createdAt lastLogin').sort({ createdAt: -1 });

    console.log('\n========================================');
    console.log('   All Registered Users');
    console.log('========================================\n');

    if (users.length === 0) {
      console.log('No users found.\n');
    } else {
      console.log(`Total Users: ${users.length}\n`);
      console.log('─'.repeat(80));
      console.log(`${'Name'.padEnd(20)} ${'Email'.padEnd(30)} ${'Role'.padEnd(12)} ${'Status'.padEnd(10)}`);
      console.log('─'.repeat(80));

      users.forEach(u => {
        const status = u.isActive ? '🟢 Active' : '🔴 Inactive';
        console.log(
          `${u.name.substring(0, 18).padEnd(20)} ` +
          `${u.email.padEnd(30)} ` +
          `${u.role.padEnd(12)} ` +
          `${status}`
        );
      });

      console.log('─'.repeat(80));
    }

    console.log('\n💡 To reset a password:');
    console.log('   node reset-password.js <email> <new-password>');
    console.log('   Example: node reset-password.js admin@school.com mynewpass\n');

  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await mongoose.disconnect();
  }
}

listUsers();
