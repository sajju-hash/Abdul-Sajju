/**
 * School ID Card Generator - Static Frontend
 * Single Page Application (SPA) - No build needed!
 * Just upload these files to Hostinger and you're done!
 */

// ==========================================
// CONFIG - Backend API URL 
// ==========================================
// STEP 1: Pehle backend deploy karein (Render.com)
// STEP 2: Backend ka URL copy karein (jaise: https://schoolid-api.onrender.com)
// STEP 3: Neeche API_URL mein woh URL paste karein
// ==========================================
const CONFIG = {
  // ▼▼▼ APNA BACKEND URL YAHAN DALEIN ▼▼▼
  API_URL: 'https://schoolid-api.onrender.com/api',
  // ▲▲▲ APNA BACKEND URL YAHAN DALEIN ▲▲▲
};

// ==========================================
// STATE
// ==========================================
const state = {
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  token: localStorage.getItem('token') || null,
  currentPage: localStorage.getItem('token') ? 'dashboard' : 'login',
  sidebarOpen: false,
  students: [],
  templates: [],
  stats: null,
  schools: [],
};

// ==========================================
// API SERVICE
// ==========================================
const api = {
  async request(method, path, data = null, isFormData = false) {
    const url = `${CONFIG.API_URL}${path}`;
    const headers = {};
    if (state.token) headers['Authorization'] = `Bearer ${state.token}`;
    if (!isFormData) headers['Content-Type'] = 'application/json';

    const options = { method, headers };
    if (data) options.body = isFormData ? data : JSON.stringify(data);

    try {
      const res = await fetch(url, options);
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.message || 'Request failed');
      return json;
    } catch (err) {
      console.error('API Error:', err);
      showToast(err.message || 'Network error', 'error');
      throw err;
    }
  },
  get(path) { return this.request('GET', path); },
  post(path, data) { return this.request('POST', path, data); },
  put(path, data) { return this.request('PUT', path, data); },
  delete(path) { return this.request('DELETE', path); },
  upload(path, formData) { return this.request('POST', path, formData, true); },
};

// ==========================================
// TOAST NOTIFICATIONS
// ==========================================
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg text-white font-medium transform transition-all duration-300 translate-x-full ${type === 'success' ? 'bg-green-500' : 'bg-red-500'}`;
  toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle mr-2"></i>${message}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.remove('translate-x-full'), 50);
  setTimeout(() => { toast.classList.add('translate-x-full'); setTimeout(() => toast.remove(), 300); }, 3000);
}

// ==========================================
// AUTH
// ==========================================
async function login(email, password) {
  try {
    const res = await api.post('/auth/login', { email, password });
    if (res.success) {
      state.token = res.data.token;
      state.user = res.data.user;
      localStorage.setItem('token', state.token);
      localStorage.setItem('user', JSON.stringify(state.user));
      state.currentPage = 'dashboard';
      render();
      showToast('Login successful!');
    }
  } catch (err) {
    // Error handled by api
  }
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  state.currentPage = 'login';
  render();
  showToast('Logged out');
}

// ==========================================
// ROUTER
// ==========================================
function navigate(page) {
  state.currentPage = page;
  state.sidebarOpen = false;
  render();
}

// ==========================================
// SIDEBAR NAVIGATION
// ==========================================
function getSidebar() {
  const isSuper = state.user?.role === 'superadmin';
  const navItems = isSuper ? [
    { page: 'superadmin', icon: 'fa-chart-pie', label: 'Dashboard' },
    { page: 'schools', icon: 'fa-school', label: 'Schools' },
    { page: 'plans', icon: 'fa-tags', label: 'Plans' },
  ] : [
    { page: 'dashboard', icon: 'fa-home', label: 'Dashboard' },
    { page: 'students', icon: 'fa-users', label: 'Students' },
    { page: 'templates', icon: 'fa-id-card', label: 'Templates' },
    { page: 'generate', icon: 'fa-print', label: 'Generate Cards' },
    { page: 'photos', icon: 'fa-camera', label: 'Photo Capture' },
    { page: 'settings', icon: 'fa-cog', label: 'Settings' },
  ];

  return `
    <aside class="fixed top-0 left-0 z-50 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 lg:translate-x-0 ${state.sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}">
      <div class="flex items-center justify-between h-16 px-6 border-b border-gray-200">
        <a href="#" onclick="navigate('${isSuper ? 'superadmin' : 'dashboard'}'); return false" class="flex items-center space-x-2">
          <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <i class="fas fa-id-card text-white text-sm"></i>
          </div>
          <span class="text-lg font-bold text-gray-900">${isSuper ? 'Super Admin' : 'ID Card Gen'}</span>
        </a>
        <button onclick="toggleSidebar()" class="lg:hidden p-2 rounded-lg hover:bg-gray-100">
          <i class="fas fa-times text-gray-500"></i>
        </button>
      </div>
      <nav class="p-4 space-y-1">
        ${navItems.map(item => `
          <a href="#" onclick="navigate('${item.page}'); return false" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${state.currentPage === item.page ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-100'}">
            <i class="fas ${item.icon} w-5 mr-3"></i>${item.label}
          </a>
        `).join('')}
      </nav>
      <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
        <div class="flex items-center space-x-3">
          <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
            <i class="fas fa-user text-blue-600"></i>
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium text-gray-900 truncate">${state.user?.name || 'User'}</p>
            <p class="text-xs text-gray-500 truncate">${state.user?.email || ''}</p>
          </div>
        </div>
      </div>
    </aside>
    ${state.sidebarOpen ? '<div class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onclick="toggleSidebar()"></div>' : ''}
  `;
}

function toggleSidebar() { state.sidebarOpen = !state.sidebarOpen; render(); }

// ==========================================
// HEADER
// ==========================================
function getHeader() {
  return `
    <header class="sticky top-0 z-30 bg-white border-b border-gray-200">
      <div class="flex items-center justify-between h-16 px-4 lg:px-8">
        <button onclick="toggleSidebar()" class="lg:hidden p-2 rounded-lg hover:bg-gray-100">
          <i class="fas fa-bars text-gray-500 text-lg"></i>
        </button>
        <div class="ml-auto flex items-center space-x-4">
          <button class="relative p-2 rounded-lg hover:bg-gray-100">
            <i class="fas fa-bell text-gray-500 text-lg"></i>
            <span class="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <div class="relative">
            <button onclick="toggleProfile()" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100">
              <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                <i class="fas fa-user text-blue-600 text-sm"></i>
              </div>
              <span class="hidden sm:block text-sm font-medium text-gray-700">${state.user?.name?.split(' ')[0] || 'User'}</span>
              <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
            </button>
          </div>
        </div>
      </div>
    </header>
  `;
}

function toggleProfile() {
  const existing = document.getElementById('profileDropdown');
  if (existing) { existing.remove(); return; }
  const dropdown = document.createElement('div');
  dropdown.id = 'profileDropdown';
  dropdown.className = 'fixed right-4 top-16 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50';
  const isSuper = state.user?.role === 'superadmin';
  dropdown.innerHTML = `
    <a href="#" onclick="navigate('settings'); document.getElementById('profileDropdown')?.remove(); return false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
      <i class="fas fa-user mr-2 text-gray-400"></i>Profile
    </a>
    ${isSuper ? `
    <a href="#" onclick="navigate('dashboard'); document.getElementById('profileDropdown')?.remove(); return false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
      <i class="fas fa-home mr-2 text-gray-400"></i>School Panel
    </a>` : `
    <a href="#" onclick="navigate('superadmin'); document.getElementById('profileDropdown')?.remove(); return false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
      <i class="fas fa-shield-alt mr-2 text-gray-400"></i>Super Admin
    </a>`}
    <div class="border-t border-gray-200 my-1"></div>
    <a href="#" onclick="logout(); document.getElementById('profileDropdown')?.remove(); return false" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50">
      <i class="fas fa-sign-out-alt mr-2"></i>Logout
    </a>
  `;
  document.body.appendChild(dropdown);
  setTimeout(() => document.addEventListener('click', function close(e) { if (!e.target.closest('button')) { dropdown.remove(); document.removeEventListener('click', close); } }), 50);
}

// ==========================================
// LOGIN PAGE
// ==========================================
function getLoginPage() {
  return `
    <div class="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <div class="w-full max-w-md">
        <div class="text-center mb-8">
          <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl shadow-lg mb-4">
            <i class="fas fa-id-card text-white text-2xl"></i>
          </div>
          <h1 class="text-3xl font-bold text-gray-900">School ID Card Generator</h1>
          <p class="text-gray-600 mt-2">Sign in to your account</p>
        </div>
        <div class="bg-white rounded-xl shadow-lg p-8">
          <form onsubmit="event.preventDefault(); handleLogin();" class="space-y-6">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <div class="relative">
                <i class="fas fa-envelope absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="email" id="loginEmail" value="admin@school.com" class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
              </div>
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div class="relative">
                <i class="fas fa-lock absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="password" id="loginPassword" value="admin123" class="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required />
                <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <i id="eyeIcon" class="fas fa-eye text-gray-400"></i>
                </button>
              </div>
            </div>
            <div class="flex items-center justify-between">
              <label class="flex items-center">
                <input type="checkbox" class="rounded border-gray-300 text-blue-600" />
                <span class="ml-2 text-sm text-gray-700">Remember me</span>
              </label>
              <a href="#" class="text-sm font-medium text-blue-600 hover:text-blue-500">Forgot password?</a>
            </div>
            <button type="submit" id="loginBtn" class="w-full bg-blue-600 text-white py-2.5 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center">
              <span id="loginText">Sign In</span>
            </button>
          </form>
          <div class="mt-6 p-4 bg-gray-50 rounded-lg">
            <p class="text-xs text-gray-500 text-center">
              <strong>Demo Credentials:</strong><br>Email: admin@school.com<br>Password: admin123<br><br>
              <strong>Super Admin:</strong><br>Email: superadmin@schoolid.com<br>Password: superadmin123
            </p>
          </div>
        </div>
      </div>
    </div>
  `;
}

async function handleLogin() {
  const btn = document.getElementById('loginBtn');
  const text = document.getElementById('loginText');
  btn.disabled = true;
  text.innerHTML = '<i class="fas fa-circle-notch fa-spin mr-2"></i>Signing in...';
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  try {
    const res = await fetch(`${CONFIG.API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const json = await res.json();
    if (json.success) {
      state.token = json.data.token;
      state.user = json.data.user;
      localStorage.setItem('token', state.token);
      localStorage.setItem('user', JSON.stringify(state.user));
      state.currentPage = state.user.role === 'superadmin' ? 'superadmin' : 'dashboard';
      render();
      showToast('Login successful!');
    } else {
      showToast(json.message || 'Login failed', 'error');
    }
  } catch (err) {
    showToast('Cannot connect to server. Make sure backend is running!', 'error');
  } finally {
    btn.disabled = false;
    text.textContent = 'Sign In';
  }
}

function togglePassword() {
  const input = document.getElementById('loginPassword');
  const icon = document.getElementById('eyeIcon');
  if (input.type === 'password') { input.type = 'text'; icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
  else { input.type = 'password'; icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
}

// ==========================================
// DASHBOARD PAGE
// ==========================================
function getDashboardPage() {
  const stats = state.stats || { overview: { totalStudents: 0, totalTemplates: 0, idCardsGenerated: 0 }, photoStats: { pending: 0 } };
  const statCards = [
    { icon: 'fa-users', color: 'bg-blue-500', value: stats.overview?.totalStudents || 0, label: 'Total Students', page: 'students' },
    { icon: 'fa-id-card', color: 'bg-green-500', value: stats.overview?.totalTemplates || 0, label: 'Templates', page: 'templates' },
    { icon: 'fa-print', color: 'bg-yellow-500', value: stats.overview?.idCardsGenerated || 0, label: 'ID Cards Generated', page: 'generate' },
    { icon: 'fa-camera', color: 'bg-red-500', value: stats.photoStats?.pending || 0, label: 'Photos Pending', page: 'photos' },
  ];
  return `
    <div class="space-y-6 fade-in">
      <div class="flex items-center justify-between">
        <div><h1 class="text-2xl font-bold text-gray-900">Dashboard</h1><p class="text-gray-600 mt-1">Overview of your ID card system</p></div>
        <a href="#" onclick="navigate('generate'); return false" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center">
          <i class="fas fa-print mr-2"></i>Generate ID Cards
        </a>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        ${statCards.map(s => `
          <a href="#" onclick="navigate('${s.page}'); return false" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow card-zoom">
            <div class="flex items-center">
              <div class="${s.color} p-3 rounded-lg"><i class="fas ${s.icon} text-white text-lg"></i></div>
              <div class="ml-4"><p class="text-sm font-medium text-gray-600">${s.label}</p><p class="text-2xl font-bold text-gray-900">${s.value}</p></div>
            </div>
          </a>
        `).join('')}
      </div>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div class="flex items-center justify-between mb-4"><h3 class="text-lg font-semibold text-gray-900">Attention Needed</h3><i class="fas fa-exclamation-circle text-red-500"></i></div>
          <div class="space-y-4">
            <div class="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div><p class="font-medium text-red-800">Students without photos</p><p class="text-sm text-red-600">${stats.photoStats?.pending || 0} students need photos</p></div>
              <a href="#" onclick="navigate('photos'); return false" class="bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-red-700">Add Photos</a>
            </div>
            <div class="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
              <div><p class="font-medium text-yellow-800">ID cards pending</p><p class="text-sm text-yellow-600">${stats.overview?.idCardsPending || 0} students need ID cards</p></div>
              <a href="#" onclick="navigate('generate'); return false" class="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-blue-700">Generate</a>
            </div>
          </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 class="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
          <div class="space-y-3">
            ${(stats.recentActivity || []).length > 0 ? stats.recentActivity.map(a => `
              <div class="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div class="flex items-center">
                  <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center"><i class="fas fa-user text-blue-600"></i></div>
                  <div class="ml-3"><p class="font-medium text-gray-900">${a.name}</p><p class="text-sm text-gray-500">Class ${a.class}-${a.section}</p></div>
                </div>
                <span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full ${a.photoStatus === 'uploaded' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">${a.photoStatus}</span>
              </div>
            `).join('') : '<p class="text-center text-gray-500 py-4">No recent activity</p>'}
          </div>
          <a href="#" onclick="navigate('students'); return false" class="block text-center text-blue-600 hover:text-blue-700 mt-4 text-sm font-medium">View all students &rarr;</a>
        </div>
      </div>
    </div>
  `;
}

// ==========================================
// STUDENTS PAGE
// ==========================================
let studentSearch = '', studentClass = '', studentSection = '';

function getStudentsPage() {
  const students = state.students || [];
  return `
    <div class="space-y-6 fade-in">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div><h1 class="text-2xl font-bold text-gray-900">Students</h1><p class="text-gray-600 mt-1">Manage student records</p></div>
        <div class="flex space-x-2">
          <button onclick="openModal('importModal')" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 flex items-center text-sm"><i class="fas fa-upload mr-2"></i>Import Excel</button>
          <button onclick="openModal('addStudentModal')" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center text-sm"><i class="fas fa-plus mr-2"></i>Add Student</button>
        </div>
      </div>
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div class="flex flex-col sm:flex-row gap-4">
          <div class="flex-1 relative">
            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <input type="text" id="studentSearch" value="${studentSearch}" oninput="studentSearch=this.value; loadStudents();" placeholder="Search students..." class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <button onclick="loadStudents()" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-filter mr-2"></i>Filter</button>
        </div>
      </div>
      <div class="overflow-x-auto rounded-lg border border-gray-200">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Roll No</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Photo</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Card</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th></tr></thead>
          <tbody class="bg-white divide-y divide-gray-200">
            ${students.length === 0 ? '<tr><td colspan="6" class="px-6 py-8 text-center text-gray-500">No students found</td></tr>' : students.map(s => `
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4"><div class="flex items-center"><div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-sm font-medium text-gray-600">${s.firstName?.[0]}${s.lastName?.[0]}</div><div class="ml-3"><p class="font-medium text-gray-900">${s.fullName}</p><p class="text-sm text-gray-500">${s.studentId}</p></div></div></td>
                <td class="px-6 py-4 text-sm text-gray-900">${s.class} - ${s.section}</td>
                <td class="px-6 py-4 text-sm text-gray-900">${s.rollNumber}</td>
                <td class="px-6 py-4"><span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full ${s.photo ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}"><i class="fas fa-${s.photo ? 'check' : 'times'} mr-1"></i>${s.photo ? 'Uploaded' : 'Pending'}</span></td>
                <td class="px-6 py-4"><span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full ${s.idCardGenerated ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}"><i class="fas fa-${s.idCardGenerated ? 'check' : 'times'} mr-1"></i>${s.idCardGenerated ? 'Generated' : 'Pending'}</span></td>
                <td class="px-6 py-4"><div class="flex space-x-2"><button onclick="viewStudent('${s.id}')" class="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><i class="fas fa-eye"></i></button><button onclick="deleteStudent('${s.id}')" class="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><i class="fas fa-trash"></i></button></div></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      ${getAddStudentModal()}
      ${getImportModal()}
    </div>
  `;
}

function getAddStudentModal() {
  return `
    <div id="addStudentModal" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 hidden flex items-center justify-center">
      <div class="bg-white rounded-xl shadow-lg max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b"><h3 class="text-lg font-semibold text-gray-900">Add New Student</h3><button onclick="closeModal('addStudentModal')" class="p-2 hover:bg-gray-100 rounded-lg"><i class="fas fa-times text-gray-400"></i></button></div>
        <form onsubmit="event.preventDefault(); handleAddStudent();" class="p-6 space-y-4">
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">First Name *</label><input type="text" id="sFirstName" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Last Name *</label><input type="text" id="sLastName" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Class *</label><input type="text" id="sClass" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Section *</label><input type="text" id="sSection" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Roll Number *</label><input type="text" id="sRollNumber" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Email (Optional)</label><input type="email" id="sEmail" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Phone (Optional)</label><input type="tel" id="sPhone" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Blood Group</label><select id="sBloodGroup" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><option value="">Select</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option></select></div>
          <div class="flex justify-end space-x-3 pt-4"><button type="button" onclick="closeModal('addStudentModal')" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50">Cancel</button><button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">Create Student</button></div>
        </form>
      </div>
    </div>
  `;
}

function getImportModal() {
  return `
    <div id="importModal" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 hidden flex items-center justify-center">
      <div class="bg-white rounded-xl shadow-lg max-w-2xl w-full mx-4 p-6">
        <div class="flex items-center justify-between mb-4"><h3 class="text-lg font-semibold text-gray-900">Import from Excel</h3><button onclick="closeModal('importModal')" class="p-2 hover:bg-gray-100 rounded-lg"><i class="fas fa-times text-gray-400"></i></button></div>
        <div class="space-y-4">
          <div class="flex items-center justify-between">
            <p class="text-gray-600">Download template to get started</p>
            <button onclick="downloadTemplate()" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 text-sm flex items-center"><i class="fas fa-download mr-2"></i>Download Template</button>
          </div>
          <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <i class="fas fa-upload text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600 mb-2">Upload your Excel file</p>
            <input type="file" id="excelFile" accept=".xlsx,.xls" onchange="handleExcelUpload(this)" class="hidden" />
            <label for="excelFile" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 cursor-pointer inline-block">Select File</label>
          </div>
        </div>
      </div>
    </div>
  `;
}

async function loadStudents() {
  try {
    const params = new URLSearchParams();
    if (studentSearch) params.set('search', studentSearch);
    if (studentClass) params.set('class', studentClass);
    if (studentSection) params.set('section', studentSection);
    const res = await api.get(`/students?${params}`);
    if (res.success) {
      state.students = res.data.students;
      render();
    }
  } catch (err) {
    state.students = [];
  }
}

async function handleAddStudent() {
  const data = {
    firstName: document.getElementById('sFirstName').value,
    lastName: document.getElementById('sLastName').value,
    class: document.getElementById('sClass').value,
    section: document.getElementById('sSection').value,
    rollNumber: document.getElementById('sRollNumber').value,
    email: document.getElementById('sEmail').value || undefined,
    phone: document.getElementById('sPhone').value || undefined,
    bloodGroup: document.getElementById('sBloodGroup').value || undefined,
  };
  try {
    await api.post('/students', data);
    showToast('Student created successfully');
    closeModal('addStudentModal');
    loadStudents();
  } catch (err) {}
}

async function deleteStudent(id) {
  if (!confirm('Are you sure?')) return;
  try {
    await api.delete(`/students/${id}`);
    showToast('Student deleted');
    loadStudents();
  } catch (err) {}
}

function viewStudent(id) {
  // Show student detail in modal or navigate to detail page
  showToast('Student detail view coming soon!');
}

function downloadTemplate() {
  window.open(`${CONFIG.API_URL.replace('/api', '')}/api/students/template`, '_blank');
}

async function handleExcelUpload(input) {
  const file = input.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append('excel', file);
  try {
    const res = await api.upload('/students/upload-excel', formData);
    if (res.success) {
      showToast(`Found ${res.data.validStudents} valid students`);
      closeModal('importModal');
      loadStudents();
    }
  } catch (err) {}
}

// ==========================================
// TEMPLATES PAGE
// ==========================================
function getTemplatesPage() {
  const templates = state.templates || [];
  return `
    <div class="space-y-6 fade-in">
      <div class="flex items-center justify-between">
        <div><h1 class="text-2xl font-bold text-gray-900">Templates</h1><p class="text-gray-600 mt-1">Manage ID card templates</p></div>
        <button onclick="showToast('Template builder coming soon!')" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-plus mr-2"></i>Create Template</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${templates.length === 0 ? '<div class="col-span-3 bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center"><p class="text-gray-500">No templates found</p></div>' : templates.map(t => `
          <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
              <div><h3 class="font-semibold text-gray-900">${t.name}</h3><p class="text-sm text-gray-500">${t.category}</p></div>
              ${t.isDefault ? '<span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full bg-blue-100 text-blue-800"><i class="fas fa-star mr-1"></i>Default</span>' : ''}
            </div>
            <div class="mt-4 aspect-[1.586] bg-gray-100 rounded-lg flex items-center justify-center"><p class="text-gray-400 text-sm">ID Card Preview</p></div>
            <div class="mt-4 flex items-center justify-between"><span class="text-xs text-gray-500">${t.dimensions?.width || 600}x${t.dimensions?.height || 378}px</span><div class="flex space-x-1"><button class="p-2 hover:bg-gray-100 rounded-lg"><i class="fas fa-pencil text-gray-500 text-sm"></i></button><button class="p-2 hover:bg-red-50 rounded-lg"><i class="fas fa-trash text-red-500 text-sm"></i></button></div></div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ==========================================
// GENERATE CARDS PAGE
// ==========================================
let selectedForCards = [];

function getGeneratePage() {
  const students = state.students || [];
  return `
    <div class="space-y-6 fade-in">
      <div><h1 class="text-2xl font-bold text-gray-900">Generate ID Cards</h1><p class="text-gray-600 mt-1">Select students and generate ID cards</p></div>
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div class="flex flex-wrap gap-2">
          <button onclick="generateCards()" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center ${selectedForCards.length === 0 ? 'opacity-50' : ''}"><i class="fas fa-print mr-2"></i>Generate PDF (${selectedForCards.length})</button>
          <button onclick="selectAllForCards()" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50">${selectedForCards.length === students.length && students.length > 0 ? 'Deselect All' : 'Select All'}</button>
        </div>
      </div>
      <div class="overflow-x-auto rounded-lg border border-gray-200">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase w-10"><input type="checkbox" onchange="selectAllForCards()" ${selectedForCards.length === students.length && students.length > 0 ? 'checked' : ''} /></th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Photo</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Card</th></tr></thead>
          <tbody class="bg-white divide-y divide-gray-200">
            ${students.length === 0 ? '<tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No students found</td></tr>' : students.map(s => `
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4"><input type="checkbox" onchange="toggleCardSelection('${s.id}')" ${selectedForCards.includes(s.id) ? 'checked' : ''} /></td>
                <td class="px-6 py-4"><div class="flex items-center"><div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-sm font-medium text-gray-600">${s.firstName?.[0]}${s.lastName?.[0]}</div><div class="ml-3"><p class="font-medium text-gray-900">${s.fullName}</p></div></div></td>
                <td class="px-6 py-4 text-sm text-gray-900">${s.class} - ${s.section}</td>
                <td class="px-6 py-4">${s.photo ? '<i class="fas fa-check-circle text-green-500"></i>' : '<span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">Pending</span>'}</td>
                <td class="px-6 py-4"><span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full ${s.idCardGenerated ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">${s.idCardGenerated ? 'Generated' : 'Pending'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function toggleCardSelection(id) {
  selectedForCards = selectedForCards.includes(id) ? selectedForCards.filter(x => x !== id) : [...selectedForCards, id];
  render();
}

function selectAllForCards() {
  const students = state.students || [];
  selectedForCards = selectedForCards.length === students.length ? [] : students.map(s => s.id);
  render();
}

async function generateCards() {
  if (selectedForCards.length === 0) { showToast('Please select at least one student', 'error'); return; }
  try {
    const res = await api.post('/idcards/generate-bulk', { studentIds: selectedForCards, format: 'pdf' });
    if (res.success) {
      showToast(`Generated ${res.data.count} ID cards`);
      if (res.data.downloadUrl) window.open(res.data.downloadUrl, '_blank');
    }
  } catch (err) {}
}

// ==========================================
// PHOTOS PAGE
// ==========================================
function getPhotosPage() {
  const needPhotos = (state.students || []).filter(s => !s.photo);
  return `
    <div class="space-y-6 fade-in">
      <div>
        <h1 class="text-2xl font-bold text-gray-900">Photo Capture</h1>
        <p class="text-gray-600 mt-1">${needPhotos.length} students need photos</p>
      </div>
      ${needPhotos.length === 0 ? `
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"><i class="fas fa-check text-green-600 text-2xl"></i></div>
          <h3 class="text-lg font-semibold text-gray-900">All caught up!</h3>
          <p class="text-gray-500 mt-2">All students have photos uploaded.</p>
        </div>
      ` : `
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          ${needPhotos.map(s => `
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center text-lg font-medium text-gray-600">${s.firstName?.[0]}${s.lastName?.[0]}</div>
                <div class="ml-3"><h3 class="font-semibold text-gray-900">${s.fullName}</h3><p class="text-sm text-gray-500">${s.class} - ${s.section} | Roll: ${s.rollNumber}</p></div>
              </div>
              <div class="flex space-x-2">
                <button onclick="showToast('Camera feature: Upload photo instead')" class="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 text-sm flex items-center justify-center"><i class="fas fa-camera mr-2"></i>Capture</button>
                <label class="flex-1 border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 text-sm cursor-pointer text-center flex items-center justify-center">
                  <i class="fas fa-upload mr-2"></i>Upload
                  <input type="file" accept="image/*" onchange="uploadPhoto(this, '${s.id}')" class="hidden" />
                </label>
              </div>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  `;
}

async function uploadPhoto(input, studentId) {
  const file = input.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append('photo', file);
  formData.append('studentId', studentId);
  try {
    await api.upload('/photos/upload', formData);
    showToast('Photo uploaded successfully');
    loadStudents();
  } catch (err) {}
}

// ==========================================
// SETTINGS PAGE
// ==========================================
function getSettingsPage() {
  return `
    <div class="space-y-6 fade-in">
      <div><h1 class="text-2xl font-bold text-gray-900">Settings</h1><p class="text-gray-600 mt-1">Manage your account settings</p></div>
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 h-fit">
          <nav class="space-y-1">
            <button class="w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg bg-blue-50 text-blue-700"><i class="fas fa-user w-5 mr-3"></i>Profile</button>
            <button class="w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg text-gray-600 hover:bg-gray-50"><i class="fas fa-lock w-5 mr-3"></i>Password</button>
          </nav>
        </div>
        <div class="lg:col-span-3">
          <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Profile Settings</h3>
            <div class="space-y-4">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Name</label><input type="text" id="profileName" value="${state.user?.name || ''}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" id="profileEmail" value="${state.user?.email || ''}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
              <button onclick="saveProfile()" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-save mr-2"></i>Save Changes</button>
            </div>
          </div>
          <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mt-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Change Password</h3>
            <form onsubmit="event.preventDefault(); changePassword();" class="space-y-4">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label><input type="password" id="currentPassword" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">New Password</label><input type="password" id="newPassword" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label><input type="password" id="confirmPassword" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
              <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-lock mr-2"></i>Change Password</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `;
}

async function saveProfile() {
  try {
    await api.put('/auth/profile', {
      name: document.getElementById('profileName').value,
      email: document.getElementById('profileEmail').value,
    });
    state.user.name = document.getElementById('profileName').value;
    localStorage.setItem('user', JSON.stringify(state.user));
    showToast('Profile updated');
    render();
  } catch (err) {}
}

async function changePassword() {
  const current = document.getElementById('currentPassword').value;
  const newPass = document.getElementById('newPassword').value;
  const confirm = document.getElementById('confirmPassword').value;
  if (newPass !== confirm) { showToast('Passwords do not match', 'error'); return; }
  try {
    await api.put('/auth/change-password', { currentPassword: current, newPassword: newPass });
    showToast('Password changed successfully');
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
  } catch (err) {}
}

// ==========================================
// SUPER ADMIN PAGES
// ==========================================
function getSuperAdminPage() {
  const stats = state.superStats || { schools: { total: 0, active: 0, trial: 0 }, revenue: '$0' };
  const schools = state.schools || [];
  return `
    <div class="space-y-6 fade-in">
      <div><h1 class="text-2xl font-bold text-gray-900">Super Admin Dashboard</h1><p class="text-gray-600 mt-1">Manage all schools and subscriptions</p></div>
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        ${[
          { icon: 'fa-school', color: 'bg-blue-500', value: stats.schools.total, label: 'Total Schools' },
          { icon: 'fa-check-circle', color: 'bg-green-500', value: stats.schools.active, label: 'Active Schools' },
          { icon: 'fa-clock', color: 'bg-yellow-500', value: stats.schools.trial, label: 'Trial Schools' },
          { icon: 'fa-dollar-sign', color: 'bg-purple-500', value: stats.revenue, label: 'Revenue' },
        ].map(s => `
          <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center">
              <div class="${s.color} p-3 rounded-lg"><i class="fas ${s.icon} text-white text-lg"></i></div>
              <div class="ml-4"><p class="text-sm font-medium text-gray-600">${s.label}</p><p class="text-2xl font-bold text-gray-900">${s.value}</p></div>
            </div>
          </div>
        `).join('')}
      </div>
      <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 class="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div class="flex flex-wrap gap-4">
          <button onclick="navigate('schools');" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">+ Add New School</button>
          <button onclick="navigate('schools');" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50">View All Schools</button>
          <button onclick="navigate('plans');" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50">Manage Plans</button>
        </div>
      </div>
    </div>
  `;
}

function getSchoolsPage() {
  const schools = state.schools || [];
  return `
    <div class="space-y-6 fade-in">
      <div class="flex items-center justify-between flex-wrap gap-4">
        <div><h1 class="text-2xl font-bold text-gray-900">All Schools</h1><p class="text-gray-600 mt-1">Manage registered schools</p></div>
        <button onclick="openModal('addSchoolModal')" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-plus mr-2"></i>Add School</button>
      </div>
      <div class="overflow-x-auto rounded-lg border border-gray-200">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50"><tr><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">School</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Plan</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Students</th><th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th></tr></thead>
          <tbody class="bg-white divide-y divide-gray-200">
            ${schools.length === 0 ? '<tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No schools found</td></tr>' : schools.map(s => `
              <tr class="hover:bg-gray-50">
                <td class="px-6 py-4"><div class="flex items-center"><div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium">${s.name?.[0]}</div><div class="ml-3"><p class="font-medium text-gray-900">${s.name}</p><p class="text-sm text-gray-500">${s.email}</p></div></div></td>
                <td class="px-6 py-4"><span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">${s.plan}</span></td>
                <td class="px-6 py-4"><span class="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full ${s.status === 'active' ? 'bg-green-100 text-green-800' : s.status === 'trial' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}">${s.status}</span></td>
                <td class="px-6 py-4 text-sm text-gray-900">${s.stats?.totalStudents || 0}</td>
                <td class="px-6 py-4"><div class="flex space-x-2"><button class="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><i class="fas fa-eye"></i></button><button class="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><i class="fas fa-trash"></i></button></div></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      ${getAddSchoolModal()}
    </div>
  `;
}

function getAddSchoolModal() {
  return `
    <div id="addSchoolModal" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 hidden flex items-center justify-center">
      <div class="bg-white rounded-xl shadow-lg max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b"><h3 class="text-lg font-semibold text-gray-900">Add New School</h3><button onclick="closeModal('addSchoolModal')" class="p-2 hover:bg-gray-100 rounded-lg"><i class="fas fa-times text-gray-400"></i></button></div>
        <form onsubmit="event.preventDefault(); handleAddSchool();" class="p-6 space-y-4">
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">School Name *</label><input type="text" id="schName" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">School Email *</label><input type="email" id="schEmail" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Admin Name *</label><input type="text" id="schAdminName" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Admin Email *</label><input type="email" id="schAdminEmail" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div><label class="block text-sm font-medium text-gray-700 mb-1">Admin Password *</label><input type="password" id="schAdminPassword" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Plan</label><select id="schPlan" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><option value="free">Free</option><option value="starter">Starter ($29/mo)</option><option value="professional">Professional ($99/mo)</option><option value="enterprise">Enterprise</option></select></div>
            <div><label class="block text-sm font-medium text-gray-700 mb-1">Max Students</label><input type="number" id="schMaxStudents" value="50" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div class="flex justify-end space-x-3 pt-4"><button type="button" onclick="closeModal('addSchoolModal')" class="border-2 border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50">Cancel</button><button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700">Create School</button></div>
        </form>
      </div>
    </div>
  `;
}

async function handleAddSchool() {
  try {
    await api.post('/superadmin/schools', {
      name: document.getElementById('schName').value,
      email: document.getElementById('schEmail').value,
      adminName: document.getElementById('schAdminName').value,
      adminEmail: document.getElementById('schAdminEmail').value,
      adminPassword: document.getElementById('schAdminPassword').value,
      plan: document.getElementById('schPlan').value,
      maxStudents: parseInt(document.getElementById('schMaxStudents').value),
    });
    showToast('School created successfully');
    closeModal('addSchoolModal');
    loadSchools();
  } catch (err) {}
}

async function loadSchools() {
  try {
    const res = await api.get('/superadmin/schools');
    if (res.success) {
      state.schools = res.data.schools;
      state.superStats = { schools: res.data.stats, revenue: '$0' };
      render();
    }
  } catch (err) {
    state.schools = [];
  }
}

function getPlansPage() {
  const plans = [
    { name: 'Free', price: '$0', period: '/month', desc: 'For small schools testing the platform', students: '50', users: '2', templates: '2', color: 'border-gray-200' },
    { name: 'Starter', price: '$29', period: '/month', desc: 'For growing schools', students: '500', users: '5', templates: '5', color: 'border-blue-500', popular: true },
    { name: 'Professional', price: '$99', period: '/month', desc: 'For large schools', students: '2,000', users: '15', templates: '20', color: 'border-purple-500' },
    { name: 'Enterprise', price: 'Custom', period: '', desc: 'For school chains', students: 'Unlimited', users: 'Unlimited', templates: 'Unlimited', color: 'border-yellow-500' },
  ];
  return `
    <div class="space-y-6 fade-in">
      <div><h1 class="text-2xl font-bold text-gray-900">Pricing Plans</h1><p class="text-gray-600 mt-1">Manage subscription plans and pricing</p></div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        ${plans.map(p => `
          <div class="bg-white rounded-xl shadow-sm border-2 ${p.color} p-6 flex flex-col">
            ${p.popular ? '<div class="bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full text-center mb-4 self-center">MOST POPULAR</div>' : ''}
            <h3 class="text-lg font-semibold text-gray-900">${p.name}</h3>
            <div class="mt-2 flex items-baseline"><span class="text-3xl font-bold text-gray-900">${p.price}</span><span class="text-gray-500 ml-1">${p.period}</span></div>
            <p class="text-sm text-gray-500 mt-2">${p.desc}</p>
            <div class="mt-6 space-y-3 flex-1">
              <div class="flex items-center"><i class="fas fa-users text-blue-500 w-5"></i><span class="text-sm ml-2">${p.students} students</span></div>
              <div class="flex items-center"><i class="fas fa-user text-blue-500 w-5"></i><span class="text-sm ml-2">${p.users} users</span></div>
              <div class="flex items-center"><i class="fas fa-id-card text-blue-500 w-5"></i><span class="text-sm ml-2">${p.templates} templates</span></div>
            </div>
            <button class="mt-6 w-full py-2 rounded-lg font-medium transition-colors ${p.popular ? 'bg-blue-600 text-white hover:bg-blue-700' : 'border-2 border-gray-300 text-gray-700 hover:bg-gray-50'}">${p.price === 'Custom' ? 'Contact Sales' : 'Edit Plan'}</button>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ==========================================
// UI UTILITIES
// ==========================================
function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

// ==========================================
// DATA LOADING
// ==========================================
async function loadDashboardData() {
  try {
    const res = await api.get('/dashboard/stats');
    if (res.success) state.stats = res.data;
  } catch (err) {}
}

async function loadTemplates() {
  try {
    const res = await api.get('/templates');
    if (res.success) state.templates = res.data.templates;
  } catch (err) {}
}

// ==========================================
// MAIN RENDER
// ==========================================
function render() {
  const app = document.getElementById('app');
  if (!state.token) {
    app.innerHTML = getLoginPage();
    return;
  }

  const pages = {
    dashboard: getDashboardPage,
    students: getStudentsPage,
    templates: getTemplatesPage,
    generate: getGeneratePage,
    photos: getPhotosPage,
    settings: getSettingsPage,
    superadmin: getSuperAdminPage,
    schools: getSchoolsPage,
    plans: getPlansPage,
  };

  const pageFn = pages[state.currentPage] || getDashboardPage;

  app.innerHTML = `
    <div class="min-h-screen bg-gray-50">
      ${getSidebar()}
      <div class="lg:ml-64">
        ${getHeader()}
        <main class="p-4 sm:p-6 lg:p-8">
          ${pageFn()}
        </main>
      </div>
    </div>
  `;
}

// ==========================================
// INIT
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
  render();
  // Load data if authenticated
  if (state.token) {
    loadDashboardData();
    loadStudents();
    loadTemplates();
    if (state.user?.role === 'superadmin') {
      loadSchools();
    }
  }
});

// Auto-refresh data every 30 seconds
setInterval(() => {
  if (state.token && state.currentPage === 'dashboard') {
    loadDashboardData();
  }
}, 30000);
